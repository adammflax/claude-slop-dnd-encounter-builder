(() => {
  'use strict';

  const timersEl = document.getElementById('timers');
  const slidesEl = document.getElementById('slides');
  const offlineEl = document.getElementById('offline');

  const WARN_BELOW_MS = 60_000;

  let bootId = null;
  let clockOffset = 0;          // serverNow - localNow, so a wrong local clock doesn't matter
  let finishedDisplayMs = 20_000;
  let timers = [];              // latest list from the server
  const cards = new Map();      // timer id -> element

  const now = () => Date.now() + clockOffset;

  // ---- startup -------------------------------------------------------------

  async function init() {
    try {
      const screen = /^\/gm\/?$/.test(location.pathname) ? 'gm' : 'bar';
      const res = await fetch(`/api/config?screen=${screen}`, { cache: 'no-store' });
      if (!res.ok) throw new Error(res.status);
      const cfg = await res.json();
      bootId = cfg.bootId;
      if (cfg.accentColor) document.documentElement.style.setProperty('--accent', cfg.accentColor);
      if (cfg.slidesEmbedUrl) {
        slidesEl.src = cfg.slidesEmbedUrl;
        slidesEl.hidden = false;
      }
      connect();
      setInterval(render, 200);
    } catch {
      // Server not up yet (e.g. the screen booted first). Try again shortly.
      setTimeout(init, 5000);
    }
  }

  // ---- live updates ----------------------------------------------------------

  let offlineTimer = null;

  function connect() {
    const es = new EventSource('/api/events');

    es.addEventListener('hello', (e) => {
      const msg = JSON.parse(e.data);
      // Server restarted (maybe with new settings): start clean.
      if (bootId && msg.bootId !== bootId) location.reload();
    });

    es.addEventListener('timers', (e) => {
      const snap = JSON.parse(e.data);
      clockOffset = snap.serverNow - Date.now();
      finishedDisplayMs = snap.finishedDisplayMs;
      timers = snap.timers;
      render();
    });

    es.addEventListener('reload', () => location.reload());

    es.onopen = () => {
      clearTimeout(offlineTimer);
      offlineEl.hidden = true;
    };
    es.onerror = () => {
      // EventSource reconnects by itself; only show the badge if it's taking a while.
      clearTimeout(offlineTimer);
      offlineTimer = setTimeout(() => { offlineEl.hidden = false; }, 5000);
    };
  }

  // ---- drawing -----------------------------------------------------------------

  function format(ms) {
    const total = Math.max(0, Math.ceil(ms / 1000));
    const m = Math.floor(total / 60);
    const s = total % 60;
    return `${m}:${String(s).padStart(2, '0')}`;
  }

  function makeCard(t) {
    const el = document.createElement('section');
    el.className = 'timer';
    el.innerHTML = '<div class="room"></div><div class="time"></div><div class="bar"></div>';
    el.querySelector('.room').textContent = t.label;
    return el;
  }

  // Size cards so however many are up, they all fit on the right-hand side.
  // One column while the digits stay big; a second column once a single
  // column would make them too small to read from across the bar.
  function sizeCards(count) {
    if (!count) return;
    const vh = window.innerHeight / 100;
    const pad = 2 * vh, gap = 1.5 * vh;
    const fit = (rows) => (window.innerHeight - 2 * pad - gap * (rows - 1)) / rows;
    let cols = 1;
    let height = Math.min(26 * vh, fit(count));
    if (height < 16 * vh) {
      cols = 2;
      height = Math.min(22 * vh, fit(Math.ceil(count / 2)));
    }
    const root = document.documentElement.style;
    root.setProperty('--card-h', `${height}px`);
    root.setProperty('--cols', cols);
  }

  function render() {
    const t0 = now();

    // Drop anything past its flashing window, even if the server's
    // "removed" update hasn't arrived yet.
    const visible = timers.filter((t) => t0 < t.endsAt + finishedDisplayMs);
    const ids = new Set(visible.map((t) => t.id));

    for (const [id, el] of cards) {
      if (!ids.has(id)) {
        cards.delete(id);
        el.classList.add('leaving');
        setTimeout(() => el.remove(), 300);
      }
    }

    sizeCards(visible.length);

    visible.forEach((t, i) => {
      let el = cards.get(t.id);
      if (!el) {
        el = makeCard(t);
        cards.set(t.id, el);
      }
      // keep DOM order = soonest-ending first
      if (timersEl.children[i] !== el) timersEl.insertBefore(el, timersEl.children[i] || null);

      const remaining = t.endsAt - t0;
      const finished = t.status === 'finished' || remaining <= 0;
      el.querySelector('.time').textContent = finished ? '0:00' : format(remaining);
      el.classList.toggle('finished', finished);
      el.classList.toggle('warn', !finished && remaining <= WARN_BELOW_MS);
      const total = t.endsAt - t.startedAt;
      el.style.setProperty('--progress', finished ? 0 : Math.max(0, remaining / total).toFixed(4));
    });
  }

  window.addEventListener('resize', () => sizeCards(cards.size));
  init();
})();
