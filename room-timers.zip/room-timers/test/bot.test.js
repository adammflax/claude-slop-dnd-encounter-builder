import { test } from 'node:test';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import { TimerStore } from '../src/timers.js';
import { createBot } from '../src/bot.js';
import { ROOMS } from '../src/rooms.js';

test('panel has one valid button per room and greys out busy rooms', async () => {
  const store = new TimerStore({ durationMs: 300_000, finishedDisplayMs: 20_000 });
  const config = {
    discord: { token: 'x', timerChannelId: '1550238578028585020', gmRoleId: '' },
    timers: { durationMs: 300_000 },
  };
  const bot = createBot({ config, store });
  store.start('HAWKINS', { id: '1', name: 'Sam' });

  const payload = bot.panelPayload();
  const rows = payload.components.map((r) => r.toJSON()); // throws if Discord limits are broken
  const buttons = rows.flatMap((r) => r.components);

  assert.ok(rows.every((r) => r.components.length <= 5));
  assert.equal(buttons.length, ROOMS.length);
  const hawkins = buttons.find((b) => b.custom_id === 'timer:start:HAWKINS');
  assert.match(hawkins.label, /Hawkins/);
  assert.equal(hawkins.style, 2); // Secondary (grey)
  assert.equal(buttons.find((b) => b.custom_id === 'timer:start:GUILDHALL').style, 1); // Primary
  assert.match(payload.content, /5-minute/);
  await bot.stop();
});

test('private replies are edited when the timer finishes and deleted after DISCORD_REPLY_DELETE_MS', async (t) => {
  t.mock.timers.enable({ apis: ['setTimeout', 'setInterval', 'Date'], now: 1_000_000 });
  const calls = [];
  const rest = {
    patch: async (route, opts) => calls.push(['patch', route, opts.body.content]),
    delete: async (route) => calls.push(['delete', route]),
  };
  const store = new TimerStore({ durationMs: 300_000, finishedDisplayMs: 20_000 });
  const config = {
    discord: { token: 'x', timerChannelId: '1550238578028585020', gmRoleId: '', replyDeleteMs: 480_000 },
    timers: { durationMs: 300_000 },
  };
  const bot = createBot({ config, store, rest });

  let n = 0;
  const fakeButton = (customId, userId) => ({
    id: `i${++n}`,
    applicationId: 'app',
    token: `tok${n}`,
    customId,
    user: { id: userId, username: 'sam' },
    member: { displayName: 'Sam', roles: [] },
    isButton: () => true,
    isChatInputCommand: () => false,
    reply: async () => {},
  });
  const press = async (i) => {
    bot.client.emit('interactionCreate', i);
    for (let k = 0; k < 5; k++) await new Promise((r) => setImmediate(r));
  };

  await press(fakeButton('timer:start:GUILDHALL', '1')); // tok1: started
  await press(fakeButton('timer:start:GUILDHALL', '2')); // tok2: someone else, "room busy"

  t.mock.timers.tick(300_000);
  store.tick();
  await new Promise((r) => setImmediate(r));
  assert.deepEqual(
    calls.filter((c) => c[0] === 'patch').map((c) => [c[1], c[2]]),
    [['/webhooks/app/tok1/messages/%40original', '⏰ **Guildhall** timer finished.']],
  );

  t.mock.timers.tick(179_999);
  assert.ok(!calls.some((c) => c[0] === 'delete'), 'nothing deleted before 8 min');
  t.mock.timers.tick(1);
  await new Promise((r) => setImmediate(r));
  const deleted = calls.filter((c) => c[0] === 'delete').map((c) => c[1]).sort();
  assert.deepEqual(deleted, ['/webhooks/app/tok1/messages/%40original', '/webhooks/app/tok2/messages/%40original']);
  await bot.stop();
});

test('pressing a second room while you have a timer running is blocked', async () => {
  const store = new TimerStore({ durationMs: 300_000, finishedDisplayMs: 20_000 });
  const config = {
    discord: { token: 'x', timerChannelId: '1550238578028585020', gmRoleId: '', replyDeleteMs: 0 },
    timers: { durationMs: 300_000 },
  };
  const bot = createBot({ config, store, rest: { patch: async () => {}, delete: async () => {} } });
  const replies = [];
  const press = async (customId) => {
    bot.client.emit('interactionCreate', {
      customId,
      user: { id: '1', username: 'sam' },
      member: { displayName: 'Sam', roles: [] },
      isButton: () => true,
      isChatInputCommand: () => false,
      id: 'x', applicationId: 'app', token: 'tok',
      reply: async (p) => replies.push(p),
    });
    for (let n = 0; n < 5; n++) await new Promise((r) => setImmediate(r));
  };

  await press('timer:start:GUILDHALL');
  await press('timer:start:DOCKSIDE');
  assert.equal(store.getByRoom('DOCKSIDE'), null, 'second timer not started');
  assert.match(replies[1].content, /already have a \*\*Guildhall\*\* timer/);
  const cancel = replies[1].components[0].toJSON().components[0];
  assert.equal(cancel.custom_id, `timer:cancel:${store.getByRoom('GUILDHALL').id}`);
  await bot.stop();
});

test('messages for a timer that ended during a restart are updated on startup', async (t) => {
  t.mock.timers.enable({ apis: ['setTimeout', 'Date'], now: 1_000_000 });
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'bot-'));
  fs.writeFileSync(
    path.join(dataDir, 'discord-replies.json'),
    JSON.stringify({
      replies: [{ id: 'i1', appId: 'app', token: 'tok1', sentAt: 1_000_000 - 360_000,
        expiresAt: 1_000_000 + 500_000, deleteAt: 1_000_000 + 120_000, timerId: 'gone' }],
    }),
  );
  const calls = [];
  const rest = { patch: async (r, o) => calls.push([r, o.body.content]), delete: async () => {} };
  const store = new TimerStore({ durationMs: 300_000, finishedDisplayMs: 20_000 });
  const config = {
    dataDir,
    discord: { token: 'x', timerChannelId: '1550238578028585020', gmRoleId: '', replyDeleteMs: 480_000 },
    timers: { durationMs: 300_000 },
  };
  const bot = createBot({ config, store, rest });
  await new Promise((r) => setImmediate(r));
  assert.deepEqual(calls, [['/webhooks/app/tok1/messages/%40original', '⏰ Timer finished.']]);
  await bot.stop();
});

test('panel links to the GM screen when PUBLIC_URL is known', async () => {
  const store = new TimerStore({ durationMs: 300_000, finishedDisplayMs: 20_000 });
  const base = { discord: { token: 'x', timerChannelId: '1550238578028585020', gmRoleId: '', replyDeleteMs: 0 }, timers: { durationMs: 300_000 } };
  const withUrl = createBot({ config: { ...base, server: { publicUrl: 'http://192.168.0.94:3000' } }, store });
  assert.match(withUrl.panelPayload().content, /GM timer screen: <http:\/\/192\.168\.0\.94:3000\/gm>/);
  const without = createBot({ config: base, store });
  assert.doesNotMatch(without.panelPayload().content, /GM timer screen/);
  await withUrl.stop();
  await without.stop();
});
