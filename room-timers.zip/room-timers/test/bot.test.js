import { test } from 'node:test';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import assert from 'node:assert/strict';
import { TimerStore } from '../src/timers.js';
import { createBot } from '../src/bot.js';
import { ROOMS } from '../src/rooms.js';
import { UsageStats } from '../src/stats.js';

test('panel has one valid button per room and greys out busy rooms', async () => {
  const store = new TimerStore({ durationMs: 300_000, finishedDisplayMs: 20_000 });
  const config = {
    discord: { token: 'x', timerChannelId: '1550238578028585020', gmRoleId: '' },
    timers: { durationMs: 300_000 },
  };
  const bot = createBot({ config, store });
  store.start('HAWKINS', { id: '1', name: 'Sam' });

  const payload = bot.panelPayload();
  const rows = payload.components.map((r) => r.toJSON()); // throws if Discord limits are broken
  const buttons = rows.flatMap((r) => r.components);

  assert.ok(rows.every((r) => r.components.length <= 5));
  assert.equal(buttons.length, ROOMS.length);
  const hawkins = buttons.find((b) => b.custom_id === 'timer:start:HAWKINS');
  assert.match(hawkins.label, /Hawkins/);
  assert.equal(hawkins.style, 2); // Secondary (grey)
  assert.equal(buttons.find((b) => b.custom_id === 'timer:start:GUILDHALL').style, 1); // Primary
  assert.match(payload.content, /5-minute/);
  await bot.stop();
});

test('private replies are edited when the timer finishes and deleted after DISCORD_REPLY_DELETE_MS', async (t) => {
  t.mock.timers.enable({ apis: ['setTimeout', 'setInterval', 'Date'], now: 1_000_000 });
  const calls = [];
  const rest = {
    patch: async (route, opts) => calls.push(['patch', route, opts.body.content]),
    delete: async (route) => calls.push(['delete', route]),
  };
  const store = new TimerStore({ durationMs: 300_000, finishedDisplayMs: 20_000 });
  const config = {
    discord: { token: 'x', timerChannelId: '1550238578028585020', gmRoleId: '', replyDeleteMs: 480_000 },
    timers: { durationMs: 300_000 },
  };
  const bot = createBot({ config, store, rest });

  let n = 0;
  const fakeButton = (customId, userId) => ({
    id: `i${++n}`,
    applicationId: 'app',
    token: `tok${n}`,
    customId,
    user: { id: userId, username: 'sam' },
    member: { displayName: 'Sam', roles: [] },
    isButton: () => true,
    isChatInputCommand: () => false,
    reply: async () => {},
  });
  const press = async (i) => {
    bot.client.emit('interactionCreate', i);
    for (let k = 0; k < 5; k++) await new Promise((r) => setImmediate(r));
  };

  await press(fakeButton('timer:start:GUILDHALL', '1')); // tok1: started
  await press(fakeButton('timer:start:GUILDHALL', '2')); // tok2: someone else, "room busy"

  t.mock.timers.tick(300_000);
  store.tick();
  await new Promise((r) => setImmediate(r));
  assert.deepEqual(
    calls.filter((c) => c[0] === 'patch').map((c) => [c[1], c[2]]),
    [['/webhooks/app/tok1/messages/%40original', '⏰ **Guildhall** timer finished.']],
  );

  t.mock.timers.tick(179_999);
  assert.ok(!calls.some((c) => c[0] === 'delete'), 'nothing deleted before 8 min');
  t.mock.timers.tick(1);
  await new Promise((r) => setImmediate(r));
  const deleted = calls.filter((c) => c[0] === 'delete').map((c) => c[1]).sort();
  assert.deepEqual(deleted, ['/webhooks/app/tok1/messages/%40original', '/webhooks/app/tok2/messages/%40original']);
  await bot.stop();
});

test('pressing a second room while you have a timer running is blocked', async () => {
  const store = new TimerStore({ durationMs: 300_000, finishedDisplayMs: 20_000 });
  const config = {
    discord: { token: 'x', timerChannelId: '1550238578028585020', gmRoleId: '', replyDeleteMs: 0 },
    timers: { durationMs: 300_000 },
  };
  const bot = createBot({ config, store, rest: { patch: async () => {}, delete: async () => {} } });
  const replies = [];
  const press = async (customId) => {
    bot.client.emit('interactionCreate', {
      customId,
      user: { id: '1', username: 'sam' },
      member: { displayName: 'Sam', roles: [] },
      isButton: () => true,
      isChatInputCommand: () => false,
      id: 'x', applicationId: 'app', token: 'tok',
      reply: async (p) => replies.push(p),
    });
    for (let n = 0; n < 5; n++) await new Promise((r) => setImmediate(r));
  };

  await press('timer:start:GUILDHALL');
  await press('timer:start:DOCKSIDE');
  assert.equal(store.getByRoom('DOCKSIDE'), null, 'second timer not started');
  assert.match(replies[1].content, /already have a \*\*Guildhall\*\* timer/);
  const ids = replies[1].components[0].toJSON().components.map((c) => c.custom_id);
  const timerId = store.getByRoom('GUILDHALL').id;
  assert.deepEqual(ids, [`timer:extend:${timerId}`, `timer:cancel:${timerId}`]);
  await bot.stop();
});

test('messages for a timer that ended during a restart are updated on startup', async (t) => {
  t.mock.timers.enable({ apis: ['setTimeout', 'Date'], now: 1_000_000 });
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'bot-'));
  fs.writeFileSync(
    path.join(dataDir, 'discord-replies.json'),
    JSON.stringify({
      replies: [{ id: 'i1', appId: 'app', token: 'tok1', sentAt: 1_000_000 - 360_000,
        expiresAt: 1_000_000 + 500_000, deleteAt: 1_000_000 + 120_000, timerId: 'gone' }],
    }),
  );
  const calls = [];
  const rest = { patch: async (r, o) => calls.push([r, o.body.content]), delete: async () => {} };
  const store = new TimerStore({ durationMs: 300_000, finishedDisplayMs: 20_000 });
  const config = {
    dataDir,
    discord: { token: 'x', timerChannelId: '1550238578028585020', gmRoleId: '', replyDeleteMs: 480_000 },
    timers: { durationMs: 300_000 },
  };
  const bot = createBot({ config, store, rest });
  await new Promise((r) => setImmediate(r));
  assert.deepEqual(calls, [['/webhooks/app/tok1/messages/%40original', '⏰ Timer finished.']]);
  await bot.stop();
});

test('panel links to the GM screen, preferring the .local name', async () => {
  const store = new TimerStore({ durationMs: 300_000, finishedDisplayMs: 20_000 });
  const base = { discord: { token: 'x', timerChannelId: '1550238578028585020', gmRoleId: '', replyDeleteMs: 0 }, timers: { durationMs: 300_000 } };
  const server = { port: 3000, publicUrl: 'http://192.168.0.94:3000' };
  const bots = [
    createBot({ config: { ...base, server, mdns: { name: 'rpg-timers' } }, store }),
    createBot({ config: { ...base, server, mdns: { name: null } }, store }),
    createBot({ config: base, store }),
  ];
  const gm = createBot({ config: { ...base, server, mdns: { name: 'rpg-timers', gmName: 'gm' } }, store });
  bots.push(gm);
  assert.match(gm.panelPayload().content, /\[GM timer screen\]\(<http:\/\/gm\.local:3000>\)/);
  const [mdns, url, none] = bots.map((b) => b.panelPayload().content);
  assert.match(mdns, /\[GM timer screen\]\(<http:\/\/rpg-timers\.local:3000\/gm>\)/);
  assert.match(url, /\[GM timer screen\]\(<http:\/\/192\.168\.0\.94:3000\/gm>\)/);
  assert.doesNotMatch(none, /GM timer screen/);
  for (const b of bots) await b.stop();
});

test('a button press another bot already answered (10062) is logged, not a crash', async () => {
  const store = new TimerStore({ durationMs: 300_000, finishedDisplayMs: 20_000 });
  const config = { discord: { token: 'x', timerChannelId: '1550238578028585020', gmRoleId: '', replyDeleteMs: 0 }, timers: { durationMs: 300_000 } };
  const bot = createBot({ config, store, rest: { patch: async () => {}, delete: async () => {} } });
  const unhandled = [];
  const onUnhandled = (e) => unhandled.push(e);
  process.on('unhandledRejection', onUnhandled);
  let replies = 0;
  bot.client.emit('interactionCreate', {
    id: 'x', applicationId: 'app', token: 'tok',
    customId: 'timer:start:GUILDHALL',
    user: { id: '1', username: 'sam' },
    member: { displayName: 'Sam', roles: [] },
    isButton: () => true,
    isChatInputCommand: () => false,
    reply: async () => {
      replies++;
      throw Object.assign(new Error('Unknown interaction'), { code: 10062, status: 404 });
    },
  });
  for (let n = 0; n < 10; n++) await new Promise((r) => setImmediate(r));
  process.off('unhandledRejection', onUnhandled);
  assert.equal(unhandled.length, 0);
  assert.equal(replies, 1, 'does not retry a reply Discord already refused');
  await bot.stop();
});


// --- extend + stats -----------------------------------------------------------

function harness({ replyDeleteMs = 0, withStats = false } = {}) {
  const calls = [];
  const rest = {
    patch: async (route, o) => calls.push(['patch', route, o.body.content]),
    delete: async (route) => calls.push(['delete', route]),
  };
  const store = new TimerStore({ durationMs: 300_000, finishedDisplayMs: 20_000 });
  const stats = withStats ? new UsageStats({ store }) : null;
  const config = {
    discord: { token: 'x', timerChannelId: '1550238578028585020', gmRoleId: '', replyDeleteMs },
    timers: { durationMs: 300_000, extendMs: 60_000 },
  };
  const bot = createBot({ config, store, rest, stats });
  let n = 0;
  const press = async (customId, userId = '1', name = 'Sam') => {
    const log = [];
    bot.client.emit('interactionCreate', {
      id: `i${++n}`, applicationId: 'app', token: `tok${n}`,
      customId,
      user: { id: userId, username: name.toLowerCase() },
      member: { displayName: name, roles: [] },
      isButton: () => true,
      isChatInputCommand: () => false,
      reply: async (p) => log.push(['reply', p]),
      update: async (p) => log.push(['update', p]),
    });
    for (let k = 0; k < 5; k++) await new Promise((r) => setImmediate(r));
    return log;
  };
  const command = async (date, userId = '9') => {
    const log = [];
    bot.client.emit('interactionCreate', {
      id: `c${++n}`, applicationId: 'app', token: `tok${n}`,
      commandName: 'timer-stats',
      user: { id: userId, username: 'boss' },
      options: { getString: () => date },
      isButton: () => false,
      isChatInputCommand: () => true,
      reply: async (p) => log.push(p),
    });
    for (let k = 0; k < 5; k++) await new Promise((r) => setImmediate(r));
    return log[0];
  };
  return { bot, store, stats, calls, press, command };
}

test('the starter can extend their timer a minute at a time', async () => {
  const { bot, store, press } = harness();
  await press('timer:start:GUILDHALL');
  const t = store.getByRoom('GUILDHALL');
  const endsAt = t.endsAt;

  const [[kind, payload]] = await press(`timer:extend:${t.id}`);
  assert.equal(kind, 'update', 'updates the same private message');
  assert.equal(store.getByRoom('GUILDHALL').endsAt, endsAt + 60_000);
  assert.match(payload.content, /extended.*\(\+1 min added\)/);
  assert.equal(payload.components[0].toJSON().components[0].custom_id, `timer:extend:${t.id}`, 'buttons stay');

  await press(`timer:extend:${t.id}`);
  assert.equal(store.getByRoom('GUILDHALL').endsAt, endsAt + 120_000);
  await bot.stop();
});

test('only the starter can extend, and not once it has finished', async () => {
  const { bot, store, press } = harness();
  await press('timer:start:GUILDHALL', '1');
  const t = store.getByRoom('GUILDHALL');
  const [[, notYours]] = await press(`timer:extend:${t.id}`, '2', 'Bob');
  assert.match(notYours.content, /Only the person who started this timer can extend it/);
  assert.equal(store.getByRoom('GUILDHALL').endsAt, t.endsAt);

  t.endsAt = Date.now() - 1; // force it to finish
  store.tick();
  const [[kind, done]] = await press(`timer:extend:${t.id}`);
  assert.equal(kind, 'update');
  assert.match(done.content, /already finished/);
  assert.deepEqual(done.components, [], 'stale buttons removed');
  await bot.stop();
});

test('extending pushes back the message auto-delete so the buttons stay until it ends', async (t) => {
  t.mock.timers.enable({ apis: ['setTimeout', 'setInterval', 'Date'], now: 1_000_000 });
  const { bot, store, calls, press } = harness({ replyDeleteMs: 480_000 });
  await press('timer:start:GUILDHALL');
  const timer = store.getByRoom('GUILDHALL');
  for (let i = 0; i < 4; i++) await press(`timer:extend:${timer.id}`); // now 9 minutes

  t.mock.timers.tick(480_000); // the old 8-minute delete time
  await new Promise((r) => setImmediate(r));
  assert.ok(!calls.some((c) => c[0] === 'delete' && c[1].includes('tok1/')), 'not deleted while still running');

  t.mock.timers.tick(240_000); // 3 minutes after the extended end (12 min)
  await new Promise((r) => setImmediate(r));
  assert.ok(calls.some((c) => c[0] === 'delete' && c[1].includes('tok1/')), 'deleted 3 min after it ends');
  await bot.stop();
});

test('/timer-stats privately lists who used the timers that day', async () => {
  const { bot, store, press, command } = harness({ withStats: true });
  await press('timer:start:GUILDHALL', '1', 'Sam');
  await press(`timer:extend:${store.getByRoom('GUILDHALL').id}`, '1', 'Sam');
  await press('timer:start:Crypt', '2', 'Bob');
  await press(`timer:cancel:${store.getByRoom('Crypt').id}`, '2', 'Bob');

  const reply = await command(null);
  assert.equal(reply.flags, 64, 'ephemeral: only the person who asked sees it');
  assert.deepEqual(reply.allowedMentions, { parse: [] }, 'nobody gets pinged');
  assert.match(reply.content, /\*\*2\*\* timers by \*\*2\*\* people/);
  assert.match(reply.content, /<@1>\*\*: 1 \(Guildhall\) · \+1 min extended/);
  assert.match(reply.content, /<@2>\*\*: 1 \(Crypt\) · 1 cancelled/);

  const bad = await command('31/02/2026');
  assert.match(bad.content, /couldn't read "31\/02\/2026" as a date/);
  const empty = await command('1/1/2020');
  assert.match(empty.content, /No timers were started that day/);
  await bot.stop();
});
