import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { ReplyTracker } from '../src/replies.js';

const interaction = (n) => ({ id: `i${n}`, applicationId: 'app', token: `tok${n}` });
const route = (n) => `/webhooks/app/tok${n}/messages/%40original`;

function fakeRest() {
  const calls = [];
  return {
    calls,
    patch: async (r, o) => calls.push(['patch', r, o.body.content, o.auth]),
    delete: async (r, o) => calls.push(['delete', r, o.auth]),
  };
}
const flush = () => new Promise((r) => setImmediate(r));

test('cleanup carries on after a restart', async (t) => {
  t.mock.timers.enable({ apis: ['setTimeout', 'Date'], now: 1_000_000 });
  const filePath = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'replies-')), 'discord-replies.json');

  // Before the restart: timer started, reply tracked.
  const before = new ReplyTracker({ rest: fakeRest(), deleteAfterMs: 480_000, filePath });
  before.track(interaction(1), { timerId: 'timer-1' });
  t.mock.timers.tick(120_000); // restart 2 minutes in
  before.stop();

  // After the restart: a fresh tracker picks the reply back up from disk.
  const rest = fakeRest();
  const after = new ReplyTracker({ rest, deleteAfterMs: 480_000, filePath });
  after.load();

  t.mock.timers.tick(180_000); // timer finishes at 5 min
  await after.editForTimer('timer-1', { content: 'finished', components: [] });
  assert.deepEqual(rest.calls, [['patch', route(1), 'finished', false]]);

  t.mock.timers.tick(179_999);
  assert.equal(rest.calls.length, 1, 'not deleted before 8 min');
  t.mock.timers.tick(1);
  await flush();
  assert.deepEqual(rest.calls[1], ['delete', route(1), false]);

  after.stop();
  assert.deepEqual(JSON.parse(fs.readFileSync(filePath, 'utf8')).replies, [], 'file emptied once done');
});

test('a reply whose delete time passed while the bot was down is deleted on startup', async (t) => {
  t.mock.timers.enable({ apis: ['setTimeout', 'Date'], now: 1_000_000 });
  const filePath = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'replies-')), 'discord-replies.json');
  const a = new ReplyTracker({ rest: fakeRest(), deleteAfterMs: 480_000, filePath });
  a.track(interaction(1));
  a.stop();

  t.mock.timers.tick(600_000); // down from 0 to 10 min: past 8, still within Discord's 15
  const rest = fakeRest();
  const b = new ReplyTracker({ rest, deleteAfterMs: 480_000, filePath });
  b.load();
  t.mock.timers.tick(0);
  await flush();
  assert.deepEqual(rest.calls, [['delete', route(1), false]]);
  b.stop();
});

test('replies older than Discord allows are dropped, not retried', async (t) => {
  t.mock.timers.enable({ apis: ['setTimeout', 'Date'], now: 1_000_000 });
  const filePath = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'replies-')), 'discord-replies.json');
  const a = new ReplyTracker({ rest: fakeRest(), deleteAfterMs: 480_000, filePath });
  a.track(interaction(1));
  a.stop();

  t.mock.timers.tick(20 * 60_000); // down for 20 min
  const rest = fakeRest();
  const b = new ReplyTracker({ rest, deleteAfterMs: 480_000, filePath });
  b.load();
  t.mock.timers.tick(60_000);
  await flush();
  assert.deepEqual(rest.calls, []);
  b.stop();
});

test('a message the person already dismissed is not an error', async (t) => {
  t.mock.timers.enable({ apis: ['setTimeout', 'Date'], now: 1_000_000 });
  const rest = { delete: async () => { const e = new Error('Unknown Message'); e.code = 10008; throw e; } };
  const tr = new ReplyTracker({ rest, deleteAfterMs: 1000 });
  tr.track(interaction(1));
  t.mock.timers.tick(1000);
  await flush();
  assert.equal(tr.replies.size, 0);
  tr.stop();
});
