import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { TimerStore, TimerError } from '../src/timers.js';
import { msUntilNext } from '../src/server.js';
import { slidesEmbedUrl } from '../src/slides.js';

function makeStore(extra = {}) {
  let clock = 1_000_000;
  const store = new TimerStore({ durationMs: 300_000, finishedDisplayMs: 20_000, now: () => clock, ...extra });
  return { store, advance: (ms) => { clock += ms; store.tick(); } };
}

const alice = { id: '1', name: 'Alice' };
const bob = { id: '2', name: 'Bob' };

test('starts a 5 minute timer', () => {
  const { store } = makeStore();
  const t = store.start('GUILDHALL', alice);
  assert.equal(t.endsAt - t.startedAt, 300_000);
  assert.equal(t.label, 'Guildhall');
  assert.equal(t.status, 'running');
});

test('one running timer per room', () => {
  const { store } = makeStore();
  store.start('GUILDHALL', alice);
  assert.throws(() => store.start('GUILDHALL', bob), (e) => e instanceof TimerError && e.code === 'ROOM_BUSY');
  store.start('DOCKSIDE', bob); // other rooms unaffected
});

test('unknown room is rejected', () => {
  const { store } = makeStore();
  assert.throws(() => store.start('NOPE', alice), { code: 'UNKNOWN_ROOM' });
});

test('only the starter can cancel', () => {
  const { store } = makeStore();
  const t = store.start('Crypt', alice);
  assert.throws(() => store.cancel(t.id, { userId: bob.id }), { code: 'NOT_OWNER' });
  store.cancel(t.id, { userId: alice.id });
  assert.equal(store.getByRoom('Crypt'), null);
});

test('finishes at zero, flashes for 20s, then disappears', () => {
  const { store, advance } = makeStore();
  const events = [];
  store.on('finished', () => events.push('finished'));
  store.on('removed', (_t, why) => events.push(why));

  const t = store.start('SEANCE', alice);
  advance(299_999);
  assert.equal(store.getByRoom('SEANCE').status, 'running');
  advance(1);
  assert.equal(store.getByRoom('SEANCE').status, 'finished');
  advance(19_999);
  assert.ok(store.getByRoom('SEANCE'), 'still on screen while flashing');
  assert.throws(() => store.cancel(t.id, { userId: alice.id }), { code: 'ALREADY_FINISHED' });
  advance(1);
  assert.equal(store.getByRoom('SEANCE'), null);
  assert.deepEqual(events, ['finished', 'expired']);
});

test('a flashing room can be restarted straight away', () => {
  const { store, advance } = makeStore();
  store.start('HAWKINS', alice);
  advance(305_000);
  const t2 = store.start('HAWKINS', bob);
  assert.equal(store.getByRoom('HAWKINS').id, t2.id);
});

test('timers survive a restart', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'timers-'));
  const filePath = path.join(dir, 'timers.json');
  let clock = 5_000_000;
  const opts = { durationMs: 300_000, finishedDisplayMs: 20_000, filePath, now: () => clock };

  const a = new TimerStore(opts);
  const t = a.start('FEYWILD', alice);
  a.start('Apothecary', bob);

  clock += 60_000;
  const b = new TimerStore(opts);
  b.load();
  assert.equal(b.getByRoom('FEYWILD').id, t.id);
  assert.equal(b.snapshot().timers.length, 2);

  clock += 400_000; // long outage: everything expired
  const c = new TimerStore(opts);
  c.load();
  assert.equal(c.snapshot().timers.length, 0);
});

test('daily reload scheduling', () => {
  const at = (s) => new Date(s);
  assert.equal(msUntilNext('17:00', at('2026-10-26T16:00:00')), 3_600_000);
  assert.equal(msUntilNext('17:00', at('2026-10-26T17:00:00')), 24 * 3_600_000);
  assert.equal(msUntilNext('17:00', at('2026-10-26T18:30:00')), 22.5 * 3_600_000);
});

test('slides URL parsing', () => {
  const id = '1Mf9i1XcxXZdcS59rd7Xmk0yjbwdyHw3BhWg_G9Z6ag4';
  const share = `https://docs.google.com/presentation/d/${id}/edit?usp=sharing`;
  assert.equal(
    slidesEmbedUrl(share, 8000),
    `https://docs.google.com/presentation/d/${id}/embed?start=true&loop=true&delayms=8000&rm=minimal`,
  );
  assert.equal(slidesEmbedUrl(id, 8000), slidesEmbedUrl(share, 8000));
  assert.match(slidesEmbedUrl('https://docs.google.com/presentation/d/e/2PACX-abc123/pub?start=false', 5000), /\/d\/e\/2PACX-abc123\/embed\?.*delayms=5000/);
  assert.equal(slidesEmbedUrl('https://example.com', 8000), null);
});

test('one running timer per person', () => {
  const { store, advance } = makeStore();
  const t = store.start('GUILDHALL', alice);
  assert.throws(() => store.start('DOCKSIDE', alice), (e) => e.code === 'USER_BUSY' && e.timer.id === t.id);
  store.start('DOCKSIDE', bob); // other people unaffected

  store.cancel(t.id, { userId: alice.id });
  const t2 = store.start('HAWKINS', alice); // free again after cancelling
  advance(300_000);
  assert.equal(store.getByRoom('HAWKINS').status, 'finished');
  store.start('SEANCE', alice); // a finished (flashing) timer doesn't block
  assert.ok(t2);
});

test('API-started timers have no per-person limit', () => {
  const { store } = makeStore();
  store.start('GUILDHALL', { id: null, name: 'API' });
  store.start('DOCKSIDE', { id: null, name: 'API' });
});
