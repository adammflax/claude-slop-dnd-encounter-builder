import { test } from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import dgram from 'node:dgram';
import dnsPacket from 'dns-packet';
import { createMdnsResponder, pickAddress, localIPv4s, normaliseName } from '../src/mdns.js';

const quiet = { info() {}, warn() {}, debug() {}, error() {} };

// The Pi on two networks: guest WiFi (wlan0) and staff WiFi (wlan1).
const twoNetworks = () => ({
  lo: [{ family: 'IPv4', address: '127.0.0.1', netmask: '255.0.0.0', internal: true }],
  wlan0: [{ family: 'IPv4', address: '192.168.0.94', netmask: '255.255.255.0', internal: false }],
  wlan1: [{ family: 'IPv4', address: '10.20.1.7', netmask: '255.255.0.0', internal: false }],
});

class FakeSocket extends EventEmitter {
  constructor() {
    super();
    this.sent = [];
    this.memberships = [];
    this.via = null;
  }
  bind(_port, cb) { cb(); }
  setMulticastTTL() {}
  setMulticastLoopback() {}
  setMulticastInterface(ip) { this.via = ip; }
  addMembership(group, ip) { this.memberships.push(ip); }
  dropMembership() {}
  send(buf, port, address, cb) {
    this.sent.push({ via: this.via, port, address, packet: dnsPacket.decode(buf) });
    setImmediate(cb);
  }
  close() {}
}

const query = (name, type = 'A', id = 0) => dnsPacket.encode({ type: 'query', id, questions: [{ name, type, class: 'IN' }] });
const flush = async () => { for (let i = 0; i < 5; i++) await new Promise((r) => setImmediate(r)); };

test('answers each network with its own address', async () => {
  const sock = new FakeSocket();
  const r = createMdnsResponder({ name: 'rpg-timers', interfaces: twoNetworks, createSocket: () => sock, log: quiet });
  await r.start();
  assert.deepEqual(sock.memberships.sort(), ['10.20.1.7', '192.168.0.94']);
  await flush();
  sock.sent.length = 0; // ignore startup announcements

  r._onMessage(query('rpg-timers.local'), { address: '192.168.0.50', port: 5353 }); // phone on guest WiFi
  r._onMessage(query('RPG-Timers.local'), { address: '10.20.9.9', port: 5353 }); // phone on staff WiFi
  await flush();

  assert.deepEqual(
    sock.sent.map((s) => [s.via, s.address, s.packet.answers[0].data]),
    [
      ['192.168.0.94', '224.0.0.251', '192.168.0.94'],
      ['10.20.1.7', '224.0.0.251', '10.20.1.7'],
    ],
  );
  await r.stop();
});

test('never renames: hearing its own (or anyone\'s) answer for the name changes nothing', async () => {
  const sock = new FakeSocket();
  const r = createMdnsResponder({ name: 'rpg-timers', interfaces: twoNetworks, createSocket: () => sock, log: quiet });
  await r.start();
  await flush();
  // Our announcement echoing back from the other network, as on the venue WiFi.
  const echo = dnsPacket.encode({ type: 'response', answers: [{ name: 'rpg-timers.local', type: 'A', ttl: 120, data: '10.20.1.7' }] });
  r._onMessage(echo, { address: '10.20.1.7', port: 5353 });
  sock.sent.length = 0;
  r._onMessage(query('rpg-timers.local'), { address: '192.168.0.50', port: 5353 });
  await flush();
  assert.equal(r.name, 'rpg-timers.local');
  assert.equal(sock.sent.length, 1);
  assert.equal(sock.sent[0].packet.answers[0].name, 'rpg-timers.local');
  await r.stop();
});

test('ignores other names, and askers on networks the Pi is not on', async () => {
  const sock = new FakeSocket();
  const r = createMdnsResponder({ name: 'rpg-timers', interfaces: twoNetworks, createSocket: () => sock, log: quiet });
  await r.start();
  await flush();
  sock.sent.length = 0;
  r._onMessage(query('raspberrypi.local'), { address: '192.168.0.50', port: 5353 });
  r._onMessage(query('rpg-timers.local'), { address: '172.16.0.5', port: 5353 });
  r._onMessage(Buffer.from('not dns'), { address: '192.168.0.50', port: 5353 });
  await flush();
  assert.equal(sock.sent.length, 0);
  await r.stop();
});

test('one-shot queries from other ports get a direct reply with the same id', async () => {
  const sock = new FakeSocket();
  const r = createMdnsResponder({ name: 'rpg-timers', interfaces: twoNetworks, createSocket: () => sock, log: quiet });
  await r.start();
  await flush();
  sock.sent.length = 0;
  r._onMessage(query('rpg-timers.local', 'A', 4242), { address: '192.168.0.50', port: 50123 });
  await flush();
  assert.equal(sock.sent[0].address, '192.168.0.50');
  assert.equal(sock.sent[0].port, 50123);
  assert.equal(sock.sent[0].packet.id, 4242);
  await r.stop();
});

test('picks up a network that appears later and announces on it', async () => {
  const sock = new FakeSocket();
  let ifaces = { wlan0: twoNetworks().wlan0 };
  const r = createMdnsResponder({ name: 'rpg-timers', interfaces: () => ifaces, createSocket: () => sock, log: quiet });
  await r.start();
  assert.deepEqual(sock.memberships, ['192.168.0.94']);
  ifaces = twoNetworks(); // USB WiFi connects to the staff network
  r._syncInterfaces();
  await flush();
  assert.deepEqual(sock.memberships, ['192.168.0.94', '10.20.1.7']);
  assert.ok(sock.sent.some((s) => s.via === '10.20.1.7'), 'announced on the new network');
  await r.stop();
});

test('helpers', () => {
  assert.equal(normaliseName('RPG-Timers'), 'rpg-timers.local');
  assert.equal(normaliseName('rpg-timers.local'), 'rpg-timers.local');
  const locals = localIPv4s(twoNetworks());
  assert.equal(locals.length, 2);
  assert.equal(pickAddress('192.168.0.200', locals).name, 'wlan0');
  assert.equal(pickAddress('10.20.200.1', locals).name, 'wlan1');
  assert.equal(pickAddress('8.8.8.8', locals), null);
});

test('real network: a one-shot lookup gets an answer', async (t) => {
  const real = localIPv4s();
  if (!real.length) return t.skip('no network interface');
  const r = createMdnsResponder({ name: 'rpg-timers-test', log: quiet });
  if (!(await r.start())) return t.skip('cannot bind mDNS port here');
  try {
    const client = dgram.createSocket('udp4');
    await new Promise((res) => client.bind(0, real[0].address, res));
    const reply = new Promise((res) => {
      client.on('message', (buf) => res(dnsPacket.decode(buf)));
      setTimeout(() => res(null), 2000).unref();
    });
    client.send(query('rpg-timers-test.local', 'A', 7), 5353, real[0].address);
    const packet = await reply;
    client.close();
    if (!packet) return t.skip('no multicast/loopback support in this environment');
    assert.equal(packet.id, 7);
    assert.equal(packet.answers[0].data, real[0].address);
  } finally {
    await r.stop();
  }
});

test('answers for both names (rpg-timers.local and gm.local), each with the right network', async () => {
  const sock = new FakeSocket();
  const r = createMdnsResponder({ names: ['rpg-timers', 'gm'], interfaces: twoNetworks, createSocket: () => sock, log: quiet });
  await r.start();
  await flush();
  assert.deepEqual(
    sock.sent[0].packet.answers.map((a) => a.name).sort(),
    ['gm.local', 'rpg-timers.local'],
    'startup announcement covers both names',
  );
  sock.sent.length = 0;
  r._onMessage(query('GM.local'), { address: '10.20.9.9', port: 5353 });
  await flush();
  assert.deepEqual(
    sock.sent[0].packet.answers.map((a) => [a.name, a.data]),
    [['gm.local', '10.20.1.7']],
    'only the name that was asked for',
  );
  await r.stop();
});
