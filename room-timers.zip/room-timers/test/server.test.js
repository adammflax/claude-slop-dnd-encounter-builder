import { test } from 'node:test';
import assert from 'node:assert/strict';
import { TimerStore } from '../src/timers.js';
import { createServer } from '../src/server.js';
import { lanAddress } from '../src/network.js';

test('/ and /gm serve the display, each with its own slideshow', async () => {
  const store = new TimerStore({ durationMs: 300_000, finishedDisplayMs: 20_000 });
  const config = {
    server: { port: 0, host: '127.0.0.1', apiToken: '' },
    display: { slidesEmbedUrl: 'https://bar.example/embed', gmSlidesEmbedUrl: 'https://gm.example/embed', reloadTime: null },
  };
  const server = createServer({ config, store });
  const http = await server.listen();
  const url = `http://127.0.0.1:${http.address().port}`;
  try {
    for (const p of ['/', '/gm', '/gm/']) {
      const res = await fetch(url + p);
      assert.equal(res.status, 200, p);
      assert.match(await res.text(), /src="\/display\.js"/, p);
    }
    assert.equal((await (await fetch(`${url}/api/config?screen=bar`)).json()).slidesEmbedUrl, 'https://bar.example/embed');
    assert.equal((await (await fetch(`${url}/api/config?screen=gm`)).json()).slidesEmbedUrl, 'https://gm.example/embed');
    assert.equal((await (await fetch(`${url}/api/config?screen=nope`)).json()).slidesEmbedUrl, 'https://bar.example/embed');
  } finally {
    await server.close();
  }
});

test('LAN address prefers a private IPv4', () => {
  const ifaces = {
    lo: [{ family: 'IPv4', address: '127.0.0.1', internal: true }],
    docker0: [{ family: 'IPv4', address: '8.8.4.4', internal: false }],
    eth0: [
      { family: 'IPv6', address: 'fe80::1', internal: false },
      { family: 'IPv4', address: '192.168.0.94', internal: false },
    ],
  };
  assert.equal(lanAddress(ifaces), '192.168.0.94');
  assert.equal(lanAddress({ lo: ifaces.lo }), null);
});
