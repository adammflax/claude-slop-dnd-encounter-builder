import { test } from 'node:test';
import assert from 'node:assert/strict';
import { TimerStore } from '../src/timers.js';
import { UsageStats, parseDateInput, localDateKey, formatStats } from '../src/stats.js';

test('date input: UK day-first, ISO, today/yesterday, and rejects nonsense', () => {
  const now = new Date(2026, 10, 6, 15, 0).getTime(); // 6 Nov 2026
  assert.equal(parseDateInput(null, now), '2026-11-06');
  assert.equal(parseDateInput('today', now), '2026-11-06');
  assert.equal(parseDateInput('Yesterday', now), '2026-11-05');
  assert.equal(parseDateInput('6/11/2026', now), '2026-11-06');
  assert.equal(parseDateInput('06/11/26', now), '2026-11-06');
  assert.equal(parseDateInput('6.11.2026', now), '2026-11-06');
  assert.equal(parseDateInput('2026-11-06', now), '2026-11-06');
  assert.equal(parseDateInput('31/02/2026', now), null);
  assert.equal(parseDateInput('next tuesday', now), null);
});

test('records starts, extensions and cancellations per person and day', () => {
  let clock = new Date(2026, 10, 6, 19, 30).getTime();
  const store = new TimerStore({ durationMs: 300_000, finishedDisplayMs: 20_000, now: () => clock });
  const stats = new UsageStats({ store, now: () => clock });

  const a = store.start('GUILDHALL', { id: '1', name: 'Sam' });
  store.extend(a.id, 60_000);
  store.extend(a.id, 60_000);
  clock += 10 * 60_000;
  store.tick();
  store.tick();
  const b = store.start('Crypt', { id: '1', name: 'Sam' });
  store.cancel(b.id);
  store.start('SEANCE', { id: '2', name: 'Bob' });

  const [sam, bob] = stats.summary(localDateKey(clock));
  assert.equal(sam.user, 'Sam');
  assert.equal(sam.count, 2);
  assert.deepEqual(sam.rooms, [['Guildhall', 1], ['Crypt', 1]]);
  assert.equal(sam.extensions, 2);
  assert.equal(sam.extendedMs, 120_000);
  assert.equal(sam.cancelled, 1);
  assert.equal(bob.count, 1);
  assert.deepEqual(stats.summary('2026-11-05'), []);
});

test('old entries are dropped after keepDays', () => {
  let clock = new Date(2026, 0, 1, 12).getTime();
  const store = new TimerStore({ durationMs: 300_000, finishedDisplayMs: 20_000, now: () => clock });
  const stats = new UsageStats({ store, keepDays: 30, now: () => clock });
  store.start('GUILDHALL', { id: '1', name: 'Sam' });
  clock += 31 * 24 * 3600_000;
  store.tick();
  store.start('DOCKSIDE', { id: '1', name: 'Sam' });
  assert.equal(stats.entries.size, 1);
});

test('the message stays under Discord\'s 2000-character limit on a very busy day', () => {
  let clock = new Date(2026, 10, 6, 10).getTime();
  const store = new TimerStore({ durationMs: 1000, finishedDisplayMs: 0, now: () => clock });
  const stats = new UsageStats({ store, now: () => clock });
  for (let i = 0; i < 400; i++) {
    store.start('GUILDHALL', { id: String(100000 + (i % 60)), name: `Person number ${i % 60}` });
    clock += 2000;
    store.tick();
  }
  const text = formatStats(stats, '2026-11-06', { since: '6 Nov, 09:00' });
  assert.ok(text.length <= 2000, `length ${text.length}`);
  assert.match(text, /…and more/);
});
