// One-off: registers the optional /timer-panel command in your server.
// Run with `npm run register` from the project folder.
// Only needed once, or again if you change the command definition.
import 'dotenv/config';
import { REST, Routes, SlashCommandBuilder, PermissionFlagsBits } from 'discord.js';

const { DISCORD_TOKEN, DISCORD_CLIENT_ID, DISCORD_GUILD_ID } = process.env;
if (!DISCORD_TOKEN || !DISCORD_CLIENT_ID || !DISCORD_GUILD_ID) {
  console.error('DISCORD_TOKEN, DISCORD_CLIENT_ID and DISCORD_GUILD_ID must be set in .env');
  process.exit(1);
}

const commands = [
  new SlashCommandBuilder()
    .setName('timer-panel')
    .setDescription('Repost the room timer buttons')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .setDMPermission(false)
    .toJSON(),
];

const rest = new REST().setToken(DISCORD_TOKEN);
await rest.put(Routes.applicationGuildCommands(DISCORD_CLIENT_ID, DISCORD_GUILD_ID), { body: commands });
console.log(`Registered /timer-panel in guild ${DISCORD_GUILD_ID}`);
