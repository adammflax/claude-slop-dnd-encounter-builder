# Room Timers

A Discord panel with one button per room. Pressing a button starts a 5-minute
timer for that room, which appears in large digits on the bar screen over a
looping Google Slides deck.

- **Discord:** one persistent panel message, one button per room. The
  confirmation is private (only the person who pressed sees it) and has a
  **Cancel timer** button that only they can use. Busy rooms turn grey.
  Each person can only have one timer running; pressing another room tells
  them so and offers to cancel the one they have.
  Private messages delete themselves after 8 minutes
  (`DISCORD_REPLY_DELETE_MS`).
- **Bar screen:** a web page with the slideshow full-screen and the timers
  stacked on the right. The last minute turns amber; at zero the card flashes
  red reading `0:00` for 20 seconds, then disappears. With six or more timers
  up it switches to two columns so the digits stay readable.
- **Restarts are safe:** running timers are saved to disk and come back after a
  restart or crash. The screen reconnects on its own and reloads itself when
  the server restarts.
- **Extend:** the private message has a **+1 min** button (only the person who
  started the timer can use it). Each press adds a minute on the screen.
- **Usage stats:** `/timer-stats` (optionally with a date like `6/11/2026` or
  `yesterday`) privately shows who started timers that day, which rooms, and
  any extensions or cancellations. Kept in memory only; a restart clears it.
- **`gm.local`:** opening `http://gm.local:3000` on either WiFi goes straight
  to the GM screen (`GM_MDNS_NAME`).
- **One name on every network:** the app answers for `rpg-timers.local`
  itself (`MDNS_NAME`), giving each WiFi the Pi's address on that network.
  Unlike Avahi it never renames itself when the Pi is on two linked networks.
- **GM screen:** `/gm` shows the same live timers over its own slideshow
  (`GM_GOOGLE_SLIDES_URL`). The Discord panel links to it.
- **Daily refresh:** the screen reloads at 17:00 (configurable) so edits to the
  slide deck show up.

## 1. Discord setup (once)

1. In the [Developer Portal](https://discord.com/developers/applications), open
   your application → **Bot** → copy the token into `DISCORD_TOKEN`.
   No privileged intents are needed.
2. Invite the bot with the `bot` and `applications.commands` scopes.
3. In the timer channel the bot needs **View Channel**, **Send Messages** and
   **Read Message History**.
4. Optional: to restrict the buttons to staff, put a role ID in
   `DISCORD_GM_ROLE_ID`.

## 2. Slideshow

The deck must be viewable by anyone with the link (Share → General access →
*Anyone with the link* → Viewer). If the screen shows a Google sign-in page
instead of slides, use **File → Share → Publish to the web** and paste that
published link into `GOOGLE_SLIDES_URL` instead; both kinds of URL work.

## 3. Configure

```bash
cp .env.example .env
# then set DISCORD_TOKEN (and anything else you want to change)
```

All options are explained in `.env.example`. Rooms live in `src/rooms.js`.

## 4. Run it

Needs Node.js 20 or newer. It runs under systemd. In the project folder:

```bash
npm ci --omit=dev
```

Your service unit needs:

- `WorkingDirectory=` set to the project folder. `.env` and the `data/`
  folder (where running timers are saved) are found relative to it.
- `ExecStart=/usr/bin/node src/index.js` (or `npm start`).
- `Restart=always`, so it comes back after a crash. If the bot token is
  wrong it exits straight away with an error in the log.
- Write access to `data/` for the service's user. Create it first if your unit
  uses `ProtectSystem=strict`, and add it to `ReadWritePaths=`.

```bash
sudo systemctl restart room-timers     # after changing code or .env
journalctl -u room-timers -f           # watch the logs
```

On `systemctl stop` or restart it saves the running timers before exiting.

The 17:00 screen refresh uses the server's time zone. Run `timedatectl` to
check it, and `sudo timedatectl set-timezone Europe/London` if it's wrong.

## 5. Point the bar screen at it

Open `http://<server-ip>:3000/` full-screen on the bar PC. For a dedicated
screen, launch Chrome in kiosk mode so it starts full-screen with no browser UI:

```bash
# Linux / Raspberry Pi
chromium --kiosk --noerrdialogs --disable-infobars --autoplay-policy=no-user-gesture-required http://<server-ip>:3000/

# Windows (shortcut target)
"C:\Program Files\Google\Chrome\Application\chrome.exe" --kiosk http://<server-ip>:3000/
```

If the screen ever loses the server, a small "Reconnecting…" badge appears in
the bottom-left corner and clears itself once it's back.

## Day-to-day

| Want to… | Do this |
|---|---|
| Change slides | Edit the Google deck. It shows up at the next 17:00 refresh, or restart the server to show it now. |
| Use a different deck | Change `GOOGLE_SLIDES_URL`, restart. The screen picks it up by itself. |
| Panel message got deleted | Restart the server, or run `/timer-panel` (see below). |
| Add or rename a room | Edit `src/rooms.js`, restart. The panel updates in place. |

### `/timer-stats` and `/timer-panel` commands

`/timer-stats` privately shows who used the timers on a given day.
`/timer-panel` reposts the panel without restarting. Register both once (and
again whenever the commands change):

```bash
npm run register
```

Only members with **Manage Server** can see them by default. To let another
role use them, go to Server Settings → Integrations → the bot → the command.

## HTTP API

| Method | Path | |
|---|---|---|
| GET | `/` | The bar display |
| GET | `/gm` | The GM display (own slideshow, same timers) |
| GET | `/healthz` | `{ ok, displays }`, for monitoring |
| GET | `/api/timers` | Current timers |
| GET | `/api/events` | Live updates (Server-Sent Events) |
| POST | `/api/timer-events` | `{"action":"start","room":"GUILDHALL"}` or `{"action":"cancel","room":"GUILDHALL"}` |

`POST /api/timer-events` needs `Authorization: Bearer <API_TOKEN>` when
`API_TOKEN` is set. When it's blank, the endpoint only accepts requests from the
server itself, so nobody on the bar Wi-Fi can start timers.

## Development

```bash
npm install
npm test                              # timer logic tests
DISCORD_ENABLED=false npm run dev     # display only, auto-restarts on edits
```

With Discord off you can start timers for testing with the API:

```bash
curl -X POST localhost:3000/api/timer-events -H 'content-type: application/json' \
  -d '{"action":"start","room":"GUILDHALL"}'
```
