import dgram from 'node:dgram';
import os from 'node:os';
import dnsPacket from 'dns-packet';
import { log as defaultLog } from './logger.js';

// A tiny mDNS (".local" name) responder for a few names, e.g. rpg-timers.local
// and gm.local.
//
// Why not just Avahi? When the Pi is on two networks that are linked somewhere
// behind the scenes, Avahi hears its own announcement come back on the other
// network, decides another device owns the name, and renames itself
// (raspberrypi-2.local). This responder deliberately does no conflict
// detection: it always answers for its name.
//
// Each question is answered with the Pi's address on the same network as the
// device asking, so one name works from the guest and staff WiFi alike.

const GROUP = '224.0.0.251';
const PORT = 5353;
const RESCAN_MS = 30_000; // pick up new networks / changed DHCP addresses

const ipToInt = (ip) => ip.split('.').reduce((n, part) => (n << 8) + Number(part), 0) >>> 0;

/** The Pi's non-internal IPv4 addresses with their netmasks. */
export function localIPv4s(interfaces = os.networkInterfaces()) {
  const out = [];
  for (const [name, addrs] of Object.entries(interfaces)) {
    for (const a of addrs ?? []) {
      if ((a.family === 'IPv4' || a.family === 4) && !a.internal) {
        out.push({ name, address: a.address, netmask: a.netmask });
      }
    }
  }
  return out;
}

/** Which of our addresses is on the same subnet as `sender`? */
export function pickAddress(sender, locals) {
  const s = ipToInt(sender);
  for (const l of locals) {
    const mask = ipToInt(l.netmask);
    if ((s & mask) === (ipToInt(l.address) & mask)) return l;
  }
  return null;
}

export function normaliseName(name) {
  return `${String(name).trim().toLowerCase().replace(/\.local\.?$/, '')}.local`;
}

export function createMdnsResponder({
  name,
  names = [name],
  ttl = 120,
  interfaces = () => os.networkInterfaces(),
  createSocket = () => dgram.createSocket({ type: 'udp4', reuseAddr: true }),
  log = defaultLog,
}) {
  const fqdns = [...new Set(names.filter(Boolean).map(normaliseName))];
  const fqdnSet = new Set(fqdns);
  let socket = null;
  let rescan = null;
  let joined = new Map(); // address -> interface name
  let closed = false;

  // Sends are queued so that "send this out of interface X" can't get mixed
  // up between two replies going out at the same moment.
  const queue = [];
  let sending = false;
  function send(viaAddress, packet, port = PORT, address = GROUP) {
    queue.push({ viaAddress, buf: dnsPacket.encode(packet), port, address });
    if (!sending) flush();
  }
  function flush() {
    const job = queue.shift();
    if (!job || closed) {
      sending = false;
      return;
    }
    sending = true;
    try {
      socket.setMulticastInterface(job.viaAddress);
      socket.send(job.buf, job.port, job.address, (err) => {
        if (err) log.warn(`mDNS: could not send via ${job.viaAddress}: ${err.message}`);
        flush();
      });
    } catch (err) {
      log.warn(`mDNS: could not send via ${job.viaAddress}: ${err.message}`);
      flush();
    }
  }

  const answer = (address, recordTtl = ttl, forNames = fqdns) => ({
    type: 'response',
    flags: dnsPacket.AUTHORITATIVE_ANSWER,
    answers: forNames.map((n) => ({ name: n, type: 'A', class: 'IN', ttl: recordTtl, flush: true, data: address })),
  });

  function announce(address) {
    // RFC 6762 §8.3: announce at least twice, one second apart.
    send(address, answer(address));
    setTimeout(() => !closed && send(address, answer(address)), 1000).unref?.();
  }

  // Join the mDNS group on every network we're on; announce on new ones.
  function syncInterfaces() {
    const current = localIPv4s(interfaces());
    const next = new Map(current.map((l) => [l.address, l.name]));
    for (const [address, ifname] of next) {
      if (joined.has(address)) continue;
      try {
        socket.addMembership(GROUP, address);
        log.info(`mDNS: answering as ${fqdns.join(', ')} on ${ifname} (${address})`);
        announce(address);
      } catch (err) {
        log.warn(`mDNS: could not listen on ${ifname} (${address}): ${err.message}`);
        next.delete(address);
      }
    }
    for (const address of joined.keys()) {
      if (next.has(address)) continue;
      try {
        socket.dropMembership(GROUP, address);
      } catch {
        // interface already gone
      }
    }
    joined = next;
    return current;
  }

  function onMessage(buf, rinfo) {
    let packet;
    try {
      packet = dnsPacket.decode(buf);
    } catch {
      return; // not a DNS packet we understand
    }
    if (packet.type !== 'query') return; // ignore responses, including our own echoing back
    const wanted = (packet.questions ?? []).filter(
      (q) => fqdnSet.has(q.name?.toLowerCase()) && (q.type === 'A' || q.type === 'ANY'),
    );
    if (!wanted.length) return;
    const askedNames = [...new Set(wanted.map((q) => q.name.toLowerCase()))];

    const local = pickAddress(rinfo.address, localIPv4s(interfaces()));
    if (!local) return; // asker isn't on any network we're on

    if (rinfo.port !== PORT) {
      // "Legacy" one-shot query (e.g. `dig -p 5353`): reply directly to the sender.
      send(local.address, { ...answer(local.address, 10, askedNames), id: packet.id, questions: wanted }, rinfo.port, rinfo.address);
    } else {
      send(local.address, answer(local.address, ttl, askedNames));
    }
  }

  return {
    name: fqdns[0],
    names: fqdns,
    start() {
      return new Promise((resolve) => {
        socket = createSocket();
        socket.on('message', onMessage);
        socket.on('error', (err) => {
          log.warn(`mDNS: ${err.message}. ${fqdns.join(', ')} will not be available.`);
          resolve(false);
        });
        socket.bind(PORT, () => {
          socket.setMulticastTTL(255);
          socket.setMulticastLoopback(true);
          syncInterfaces();
          rescan = setInterval(syncInterfaces, RESCAN_MS);
          rescan.unref?.();
          resolve(true);
        });
      });
    },
    async stop() {
      clearInterval(rescan);
      if (!socket) return;
      // Goodbye (TTL 0) so phones forget the name straight away.
      for (const address of joined.keys()) send(address, answer(address, 0));
      await new Promise((r) => setTimeout(r, 100));
      closed = true;
      try {
        socket.close();
      } catch {
        // already closed
      }
    },
    // exposed for tests
    _onMessage: onMessage,
    _syncInterfaces: () => syncInterfaces(),
  };
}
