// In-memory record of who used the timers, for the /timer-stats command.
// Nothing is written to disk: a restart clears it. Entries older than
// `keepDays` are dropped so memory stays bounded however long it runs.

const DAY = 24 * 60 * 60 * 1000;

/** YYYY-MM-DD for a timestamp, in the server's local time zone. */
export function localDateKey(ms) {
  const d = new Date(ms);
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

/**
 * Turn what someone typed into a YYYY-MM-DD key. Accepts:
 *   today, yesterday, 2026-11-06, 6/11/2026, 06/11/26, 6-11-2026, 6.11.2026 (UK day-first)
 * Returns null if it doesn't look like a real date.
 */
export function parseDateInput(input, now = Date.now()) {
  const s = String(input ?? '').trim().toLowerCase();
  if (!s || s === 'today') return localDateKey(now);
  if (s === 'yesterday') {
    const d = new Date(now);
    d.setDate(d.getDate() - 1);
    return localDateKey(d.getTime());
  }
  let y, m, d;
  let match = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
  if (match) [, y, m, d] = match.map(Number);
  else if ((match = s.match(/^(\d{1,2})[/.-](\d{1,2})[/.-](\d{2}|\d{4})$/))) {
    [, d, m, y] = match.map(Number);
    if (y < 100) y += 2000;
  } else return null;
  const date = new Date(y, m - 1, d);
  if (date.getFullYear() !== y || date.getMonth() !== m - 1 || date.getDate() !== d) return null; // e.g. 31/02
  return localDateKey(date.getTime());
}

export class UsageStats {
  constructor({ store, keepDays = 60, now = Date.now } = {}) {
    this.keepDays = keepDays;
    this.now = now;
    this.entries = new Map(); // timer id -> entry
    if (store) this.attach(store);
  }

  attach(store) {
    store.on('started', (t) => this.#started(t));
    store.on('extended', (t, ms) => {
      const e = this.entries.get(t.id);
      if (e) {
        e.extensions += 1;
        e.extendedMs += ms;
      }
    });
    store.on('finished', (t) => {
      const e = this.entries.get(t.id);
      if (e) e.outcome = 'finished';
    });
    store.on('removed', (t, why) => {
      const e = this.entries.get(t.id);
      if (e && why === 'cancelled') {
        e.outcome = 'cancelled';
        e.cancelledAt = this.now();
      }
    });
  }

  #started(t) {
    this.#prune();
    this.entries.set(t.id, {
      timerId: t.id,
      room: t.label,
      userId: t.startedBy.id,
      user: t.startedBy.name,
      startedAt: t.startedAt,
      extensions: 0,
      extendedMs: 0,
      outcome: 'running',
    });
  }

  #prune() {
    const cutoff = this.now() - this.keepDays * DAY;
    for (const [id, e] of this.entries) if (e.startedAt < cutoff) this.entries.delete(id);
  }

  /** Every timer started on that local date, oldest first. */
  forDate(dateKey) {
    return [...this.entries.values()]
      .filter((e) => localDateKey(e.startedAt) === dateKey)
      .sort((a, b) => a.startedAt - b.startedAt);
  }

  /** Per-person summary for that date, busiest first. */
  summary(dateKey) {
    const people = new Map();
    for (const e of this.forDate(dateKey)) {
      const key = e.userId ?? `api:${e.user}`;
      const p = people.get(key) ?? { user: e.user, userId: e.userId, timers: [], rooms: new Map() };
      p.user = e.user; // latest display name
      p.timers.push(e);
      p.rooms.set(e.room, (p.rooms.get(e.room) ?? 0) + 1);
      people.set(key, p);
    }
    return [...people.values()]
      .map((p) => ({
        user: p.user,
        userId: p.userId,
        count: p.timers.length,
        rooms: [...p.rooms].sort((a, b) => b[1] - a[1]),
        extensions: p.timers.reduce((n, e) => n + e.extensions, 0),
        extendedMs: p.timers.reduce((n, e) => n + e.extendedMs, 0),
        cancelled: p.timers.filter((e) => e.outcome === 'cancelled').length,
        timers: p.timers,
      }))
      .sort((a, b) => b.count - a.count || a.user.localeCompare(b.user));
  }

  oldestDate() {
    let oldest = null;
    for (const e of this.entries.values()) if (oldest === null || e.startedAt < oldest) oldest = e.startedAt;
    return oldest === null ? null : localDateKey(oldest);
  }
}

const hhmm = (ms) =>
  new Date(ms).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', hour12: false });

/** Discord message text for a date. Kept under Discord's 2000-character limit. */
export function formatStats(stats, dateKey, { since = null } = {}) {
  const [y, m, d] = dateKey.split('-').map(Number);
  const pretty = new Date(y, m - 1, d).toLocaleDateString('en-GB', {
    weekday: 'short', day: 'numeric', month: 'short', year: 'numeric',
  });
  const people = stats.summary(dateKey);
  const header = `## 📊 Timer use on ${pretty}\n`;
  const footer = since
    ? `\n-# Kept in memory since the bot last started (${since}); a restart clears it.`
    : `\n-# Kept in memory only; a restart clears it.`;

  if (!people.length) return `${header}No timers were started that day.${footer}`;

  const total = people.reduce((n, p) => n + p.count, 0);
  const lines = [`**${total}** timer${total === 1 ? '' : 's'} by **${people.length}** ${people.length === 1 ? 'person' : 'people'}.\n`];
  for (const p of people) {
    const who = p.userId ? `<@${p.userId}>` : p.user;
    const rooms = p.rooms.map(([room, n]) => (n > 1 ? `${room} ×${n}` : room)).join(', ');
    const extras = [
      p.extensions ? `+${Math.round(p.extendedMs / 60000)} min extended` : null,
      p.cancelled ? `${p.cancelled} cancelled` : null,
    ].filter(Boolean);
    lines.push(`**${who}**: ${p.count} (${rooms})${extras.length ? ` · ${extras.join(' · ')}` : ''}`);
    const times = p.timers
      .map((e) => `${hhmm(e.startedAt)} ${e.room}${e.extendedMs ? ` +${Math.round(e.extendedMs / 60000)}m` : ''}${e.outcome === 'cancelled' ? ' ✖' : ''}`)
      .join(' · ');
    lines.push(`-# ${times}`);
  }

  let body = '';
  for (const line of lines) {
    const next = body + line + '\n';
    if ((header + next + footer).length > 1900) {
      body += '…and more (too many to show)\n';
      break;
    }
    body = next;
  }
  return header + body.trimEnd() + footer;
}
