import fs from 'node:fs';
import path from 'node:path';
import { Routes } from 'discord.js';
import { log } from './logger.js';

// Discord lets a bot edit or delete its reply to a button press for 15 minutes,
// using that interaction's token. We keep a little margin.
const TOKEN_LIFETIME_MS = 15 * 60 * 1000 - 30 * 1000;

/**
 * Keeps track of the bot's private replies so it can edit them (e.g. "timer
 * finished") and delete them later.
 *
 * Each reply is saved to disk with its interaction token, so a restart of the
 * bot doesn't strand messages: on startup it picks the list back up and
 * carries on, as long as Discord's 15-minute token window hasn't passed.
 * Edits and deletes go straight to Discord's REST API with the token, so they
 * don't need the original interaction object.
 */
export class ReplyTracker {
  constructor({ rest, deleteAfterMs, filePath = null, now = Date.now }) {
    this.rest = rest;
    this.deleteAfterMs = deleteAfterMs;
    this.filePath = filePath;
    this.now = now;
    this.replies = new Map(); // interaction id -> record
    this.timeouts = new Map(); // interaction id -> setTimeout handle
  }

  /** Call right after replying to `interaction`. `timerId` links the reply to a timer for later edits. */
  track(interaction, { timerId = null } = {}) {
    const sentAt = this.now();
    const record = {
      id: interaction.id,
      appId: interaction.applicationId,
      token: interaction.token,
      sentAt,
      expiresAt: sentAt + TOKEN_LIFETIME_MS,
      deleteAt: this.deleteAfterMs ? sentAt + this.deleteAfterMs : null,
      timerId,
    };
    this.replies.set(record.id, record);
    this.#schedule(record);
    this.save();
  }

  /** Edit every live reply linked to this timer (e.g. to say it finished and remove the Cancel button). */
  async editForTimer(timerId, body, { exceptId = null } = {}) {
    const jobs = [];
    for (const r of this.replies.values()) {
      if (r.timerId !== timerId || r.id === exceptId) continue;
      r.timerId = null; // only edit once; it's no longer tied to a live timer
      if (this.now() >= r.expiresAt) continue;
      jobs.push(
        this.rest
          .patch(Routes.webhookMessage(r.appId, r.token, '@original'), { body, auth: false })
          .catch((err) => this.#failed('edit', r, err)),
      );
    }
    this.save();
    await Promise.all(jobs);
  }

  /** Timer IDs that still have replies waiting for a "finished"/"cancelled" edit. */
  linkedTimerIds() {
    return new Set([...this.replies.values()].map((r) => r.timerId).filter(Boolean));
  }

  /** Stop linking a reply to its timer (it has been updated by other means). */
  unlink(interactionId) {
    const r = this.replies.get(interactionId);
    if (r) {
      r.timerId = null;
      this.save();
    }
  }

  async delete(id) {
    const r = this.replies.get(id);
    this.#forget(id);
    if (!r || this.now() >= r.expiresAt) return;
    try {
      await this.rest.delete(Routes.webhookMessage(r.appId, r.token, '@original'), { auth: false });
      log.debug(`Deleted private reply ${id}`);
    } catch (err) {
      this.#failed('delete', r, err);
    }
  }

  load() {
    if (!this.filePath || !fs.existsSync(this.filePath)) return;
    try {
      const saved = JSON.parse(fs.readFileSync(this.filePath, 'utf8'));
      let restored = 0;
      for (const r of saved.replies ?? []) {
        if (!r?.id || !r.token || !r.appId || !(this.now() < r.expiresAt)) continue;
        this.replies.set(r.id, r);
        this.#schedule(r);
        restored++;
      }
      if (restored) log.info(`Picked up ${restored} private Discord message(s) still waiting to be cleaned up`);
      this.save(); // drop expired ones from the file
    } catch (err) {
      log.warn(`Could not read saved Discord replies (${err.message}); starting empty`);
    }
  }

  save() {
    if (!this.filePath) return;
    try {
      fs.mkdirSync(path.dirname(this.filePath), { recursive: true });
      const tmp = `${this.filePath}.tmp`;
      fs.writeFileSync(tmp, JSON.stringify({ replies: [...this.replies.values()] }, null, 2), { mode: 0o600 });
      fs.renameSync(tmp, this.filePath);
    } catch (err) {
      log.error(`Could not save Discord replies: ${err.message}`);
    }
  }

  stop() {
    for (const h of this.timeouts.values()) clearTimeout(h);
    this.timeouts.clear();
    this.save();
  }

  // --- internals ------------------------------------------------------------

  #schedule(r) {
    // Delete at deleteAt; if there's no auto-delete, just forget the record
    // once the token expires so the file doesn't grow.
    const at = r.deleteAt ?? r.expiresAt;
    const wait = Math.max(0, Math.min(at, r.expiresAt) - this.now());
    clearTimeout(this.timeouts.get(r.id));
    const handle = setTimeout(() => {
      if (r.deleteAt) this.delete(r.id);
      else this.#forget(r.id);
    }, wait);
    handle.unref?.();
    this.timeouts.set(r.id, handle);
  }

  #forget(id) {
    clearTimeout(this.timeouts.get(id));
    this.timeouts.delete(id);
    if (this.replies.delete(id)) this.save();
  }

  #failed(action, r, err) {
    // 10008 Unknown Message: the person already dismissed it. Nothing to do.
    if (err?.code === 10008 || err?.status === 404) {
      log.debug(`Private reply ${r.id} already gone (${action})`);
      return;
    }
    log.warn(`Could not ${action} private Discord reply ${r.id}: ${err?.message ?? err}`);
  }
}
