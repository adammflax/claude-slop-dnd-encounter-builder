import path from 'node:path';
import { config } from './config.js';
import { TimerStore } from './timers.js';
import { createServer } from './server.js';
import { createBot } from './bot.js';
import { log } from './logger.js';

const store = new TimerStore({
  durationMs: config.timers.durationMs,
  finishedDisplayMs: config.timers.finishedDisplayMs,
  filePath: path.join(config.dataDir, 'timers.json'),
});

let server = null;
let bot = null;
let shuttingDown = false;

async function shutdown(code = 0) {
  if (shuttingDown) return;
  shuttingDown = true;
  log.info('Shutting down...');
  store.stopTicking();
  store.save();
  await Promise.allSettled([server?.close(), bot?.stop()]);
  process.exit(code);
}

process.on('SIGINT', () => shutdown(0));
process.on('SIGTERM', () => shutdown(0));
process.on('unhandledRejection', (err) => log.error('Unhandled rejection:', err));
process.on('uncaughtException', (err) => {
  log.error('Uncaught exception:', err);
  shutdown(1);
});

store.load();
store.startTicking();

if (!config.display.slidesEmbedUrl) {
  log.warn('GOOGLE_SLIDES_URL is not set; the display will show a plain background');
}

// Display first: the bar screen keeps working even if Discord is having a bad day.
server = createServer({ config, store });
await server.listen();
if (config.server.publicUrl) {
  log.info(`Bar screen: ${config.server.publicUrl}/   GM screen: ${config.server.publicUrl}/gm`);
} else {
  log.warn('Could not work out this server\'s LAN address; set PUBLIC_URL so the GM link can go in Discord');
}

// Errors that retrying won't fix: exit so the problem is obvious in the logs.
const FATAL_LOGIN = new Set(['TokenInvalid', 'TokenMissing', 'DisallowedIntents']);

async function loginWithRetry() {
  let delay = 5_000;
  while (!shuttingDown) {
    try {
      await bot.start();
      return; // from here discord.js handles reconnects by itself
    } catch (err) {
      const code = err.code ?? '';
      if (FATAL_LOGIN.has(code) || /invalid token|disallowed intents/i.test(err.message)) {
        log.error(`Discord login failed: ${err.message}. Check DISCORD_TOKEN in .env.`);
        return shutdown(1);
      }
      // Usually the internet isn't up yet (or Discord is having an outage).
      // Keep the display running and try again rather than restarting the
      // whole app, which would make the bar screen flicker and reload.
      log.warn(`Discord login failed (${err.message}); retrying in ${delay / 1000}s. Display is still running.`);
      await new Promise((r) => setTimeout(r, delay));
      delay = Math.min(delay * 2, 60_000);
    }
  }
}

if (config.discord.enabled) {
  bot = createBot({ config, store });
  loginWithRetry();
} else {
  log.warn('DISCORD_ENABLED=false: running the display server only');
}
