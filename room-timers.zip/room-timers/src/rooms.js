// The rooms that get a button on the Discord panel and a timer on the display.
// `value` is the stable ID (used in button IDs and saved state), `label` is
// what people see. Changing a label is safe; changing a value will orphan any
// timer that is running for that room at the moment you restart.
export const ROOMS = [
  { label: 'Guildhall', value: 'GUILDHALL' },
  { label: 'Dockside', value: 'DOCKSIDE' },
  { label: 'Hawkins', value: 'HAWKINS' },
  { label: 'Seance', value: 'SEANCE' },
  { label: 'Feywild', value: 'FEYWILD' },
  { label: 'Apothecary', value: 'Apothecary' },
  { label: 'Crypt', value: 'Crypt' },
];

const byValue = new Map(ROOMS.map((r) => [r.value, r]));

export function getRoom(value) {
  return byValue.get(value) ?? null;
}
