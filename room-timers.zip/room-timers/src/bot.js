import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  Client,
  Events,
  GatewayIntentBits,
  MessageFlags,
  PermissionFlagsBits,
} from 'discord.js';
import { ROOMS, getRoom } from './rooms.js';
import { TimerError } from './timers.js';
import { ReplyTracker } from './replies.js';
import path from 'node:path';
import { log } from './logger.js';

const START = 'timer:start:';
const CANCEL = 'timer:cancel:';
export const PANEL_COMMAND = 'timer-panel';

const ts = (ms, style = 'R') => `<t:${Math.floor(ms / 1000)}:${style}>`;
const minutes = (ms) => Math.round(ms / 60000);

export function createBot({ config, store, rest = null }) {
  const client = new Client({ intents: [GatewayIntentBits.Guilds] });
  const { gmRoleId, timerChannelId } = config.discord;

  // Private replies we still need to edit (timer finished/cancelled) or
  // delete. Saved to disk so a restart doesn't leave messages behind.
  const replies = new ReplyTracker({
    rest: rest ?? client.rest,
    deleteAfterMs: config.discord.replyDeleteMs,
    filePath: config.dataDir ? path.join(config.dataDir, 'discord-replies.json') : null,
  });
  replies.load();

  // Timers that finished (or were cancelled) while the bot was restarting
  // never told their messages. Update those now so no stale Cancel buttons
  // are left behind.
  for (const timerId of replies.linkedTimerIds()) {
    const timer = store.getById(timerId);
    if (timer?.status === 'running') continue;
    const what = timer ? `**${timer.label}** timer` : 'Timer';
    replies.editForTimer(timerId, { content: `⏰ ${what} finished.`, components: [] });
  }
  let panelMessage = null;
  let panelUpdate = null;

  // --- panel ---------------------------------------------------------------

  function panelPayload() {
    const buttons = ROOMS.map((room) => {
      const running = store.getByRoom(room.value)?.status === 'running';
      return new ButtonBuilder()
        .setCustomId(START + room.value)
        .setLabel(running ? `${room.label} ⏱` : room.label)
        .setStyle(running ? ButtonStyle.Secondary : ButtonStyle.Primary);
    });
    // Discord allows 5 buttons per row; split evenly for a tidier panel.
    const perRow = buttons.length <= 5 ? buttons.length : Math.ceil(buttons.length / 2);
    const rows = [];
    for (let i = 0; i < buttons.length; i += perRow) {
      rows.push(new ActionRowBuilder().addComponents(buttons.slice(i, i + perRow)));
    }
    return {
      content:
        `## ⏱️ Room timers\n` +
        `Press a room to start its ${minutes(config.timers.durationMs)}-minute timer on the bar screen. ` +
        `Only you will see the confirmation, and you can cancel from there. ` +
        `You can run one timer at a time.\n` +
        (config.server?.publicUrl
          ? `GM timer screen: <${config.server.publicUrl}/gm>\n`
          : '') +
        `-# Grey buttons have a timer running.`,
      components: rows,
    };
  }

  function isPanel(msg) {
    return (
      msg.author?.id === client.user.id &&
      msg.components?.some((row) => row.components?.some((c) => c.customId?.startsWith(START)))
    );
  }

  /** Reuse the existing panel message if there is one (edit it), otherwise post a new one. */
  async function ensurePanel({ repost = false } = {}) {
    const channel = await client.channels.fetch(timerChannelId).catch(() => null);
    if (!channel || channel.type !== ChannelType.GuildText) {
      throw new Error(`DISCORD_TIMER_CHANNEL_ID ${timerChannelId} is not a text channel the bot can see`);
    }
    const perms = channel.permissionsFor(client.user);
    const needed = [
      PermissionFlagsBits.ViewChannel,
      PermissionFlagsBits.SendMessages,
      PermissionFlagsBits.ReadMessageHistory,
    ];
    if (!perms?.has(needed)) {
      throw new Error(`Bot needs View Channel, Send Messages and Read Message History in #${channel.name}`);
    }

    const recent = await channel.messages.fetch({ limit: 50 });
    const panels = [...recent.values()].filter(isPanel).sort((a, b) => b.createdTimestamp - a.createdTimestamp);

    if (panels.length && !repost) {
      panelMessage = await panels[0].edit(panelPayload());
      for (const extra of panels.slice(1)) await extra.delete().catch(() => {});
      log.info(`Timer panel updated in #${channel.name}`);
    } else {
      for (const old of panels) await old.delete().catch(() => {});
      panelMessage = await channel.send(panelPayload());
      log.info(`Timer panel posted in #${channel.name}`);
    }
  }

  // Grey out busy rooms. Debounced so bursts of changes cost one edit.
  function schedulePanelUpdate() {
    if (!panelMessage) return;
    clearTimeout(panelUpdate);
    panelUpdate = setTimeout(() => {
      panelMessage.edit(panelPayload()).catch((err) => {
        log.warn(`Could not refresh panel (${err.message}); reposting`);
        ensurePanel().catch((e) => log.error('Panel repost failed:', e.message));
      });
    }, 1000);
  }

  // --- helpers ---------------------------------------------------------------

  function hasGmRole(interaction) {
    if (!gmRoleId) return true;
    const roles = interaction.member?.roles;
    if (Array.isArray(roles)) return roles.includes(gmRoleId); // uncached member
    return roles?.cache?.has(gmRoleId) ?? false;
  }

  const cancelRow = (timer) =>
    new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(CANCEL + timer.id).setLabel('Cancel timer').setStyle(ButtonStyle.Danger),
    );

  const privately = (payload) => ({ ...payload, flags: MessageFlags.Ephemeral });

  // Reply privately, and remember the reply so it gets cleaned up later.
  // `timerId` links it to a timer: when that timer finishes or is cancelled,
  // the message is updated and its Cancel button removed.
  async function replyPrivately(interaction, payload, { timerId = null } = {}) {
    await interaction.reply(privately(payload));
    replies.track(interaction, { timerId });
  }

  // --- interactions ----------------------------------------------------------

  async function onStart(interaction, roomValue) {
    const room = getRoom(roomValue);
    if (!room) {
      return replyPrivately(interaction, { content: 'That room no longer exists. The panel will refresh.' })
        .finally(() => ensurePanel().catch(() => {}));
    }
    const user = interaction.user;
    const name = interaction.member?.displayName ?? user.globalName ?? user.username;

    try {
      const timer = store.start(room.value, { id: user.id, name });
      await replyPrivately(
        interaction,
        {
          content: `⏱️ **${room.label}** timer started. It ends ${ts(timer.endsAt)} (${ts(timer.endsAt, 'T')}).`,
          components: [cancelRow(timer)],
        },
        { timerId: timer.id },
      );
    } catch (err) {
      if (!(err instanceof TimerError)) throw err;
      const t = err.timer;
      if (err.code === 'USER_BUSY') {
        return await replyPrivately(
          interaction,
          {
            content:
              `You already have a **${t.label}** timer running. It ends ${ts(t.endsAt)}.\n` +
              `You can only run one timer at a time. Cancel it to start **${room.label}** instead.`,
            components: [cancelRow(t)],
          },
          { timerId: t.id },
        );
      }
      if (err.code !== 'ROOM_BUSY') throw err;
      const mine = t.startedBy.id === user.id;
      await replyPrivately(
        interaction,
        {
          content: mine
            ? `You already have a **${room.label}** timer running. It ends ${ts(t.endsAt)}.`
            : `**${room.label}** already has a timer running (started by ${t.startedBy.name}). It ends ${ts(t.endsAt)}.`,
          components: mine ? [cancelRow(t)] : [],
        },
        { timerId: mine ? t.id : null },
      );
    }
  }

  async function onCancel(interaction, timerId) {
    try {
      const timer = store.cancel(timerId, { userId: interaction.user.id });
      // Update the message they pressed straight away. The 'removed' listener
      // below updates any other messages for this timer.
      await interaction.update({ content: `✖️ **${timer.label}** timer cancelled.`, components: [] });
    } catch (err) {
      if (!(err instanceof TimerError)) throw err;
      if (err.code === 'NOT_OWNER') {
        return replyPrivately(interaction, { content: err.message });
      }
      // Already finished/cancelled: just clear the stale button.
      await interaction.update({ content: err.message, components: [] });
    }
  }

  client.on(Events.InteractionCreate, async (interaction) => {
    try {
      if (interaction.isButton()) {
        const id = interaction.customId;
        if (!id.startsWith(START) && !id.startsWith(CANCEL)) return;
        if (!hasGmRole(interaction)) {
          return replyPrivately(interaction, { content: "You don't have permission to use the room timers." });
        }
        if (id.startsWith(START)) return await onStart(interaction, id.slice(START.length));
        return await onCancel(interaction, id.slice(CANCEL.length));
      }

      if (interaction.isChatInputCommand() && interaction.commandName === PANEL_COMMAND) {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        replies.track(interaction);
        await ensurePanel({ repost: true });
        return interaction.editReply(`Timer panel reposted in <#${timerChannelId}>.`);
      }
    } catch (err) {
      log.error('Interaction failed:', err);
      const msg = { content: 'Something went wrong. Please try again.', components: [] };
      if (interaction.deferred || interaction.replied) interaction.editReply(msg).catch(() => {});
      else replyPrivately(interaction, msg).catch(() => {});
    }
  });

  // --- react to timer lifecycle ----------------------------------------------

  store.on('change', schedulePanelUpdate);

  store.on('finished', (timer) => {
    replies.editForTimer(timer.id, { content: `⏰ **${timer.label}** timer finished.`, components: [] });
  });

  store.on('removed', (timer, why) => {
    if (why === 'cancelled') {
      replies.editForTimer(timer.id, { content: `✖️ **${timer.label}** timer cancelled.`, components: [] });
    }
  });

  // --- lifecycle ---------------------------------------------------------------

  client.once(Events.ClientReady, async (c) => {
    log.info(`Discord: logged in as ${c.user.tag}`);
    try {
      await ensurePanel();
    } catch (err) {
      log.error(`Could not set up the timer panel: ${err.message}`);
    }
  });

  client.on(Events.Error, (err) => log.error('Discord client error:', err));
  client.on(Events.ShardDisconnect, () => log.warn('Discord: disconnected, will reconnect'));
  client.on(Events.ShardResume, () => log.info('Discord: reconnected'));

  return {
    client,
    panelPayload, // exposed for tests
    start: () => client.login(config.discord.token),
    stop: async () => {
      clearTimeout(panelUpdate);
      replies.stop();
      await client.destroy();
    },
  };
}
