import { EventEmitter } from 'node:events';
import { randomUUID } from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { getRoom } from './rooms.js';
import { log } from './logger.js';

export class TimerError extends Error {
  constructor(code, message, timer = null) {
    super(message);
    this.code = code;
    this.timer = timer;
  }
}

/**
 * Holds every timer, one per room at most.
 *
 * Lifecycle:  running --(endsAt)--> finished --(endsAt + finishedDisplayMs)--> removed
 *             running --cancel()--> removed
 *
 * Events:
 *   'change'   (snapshot)   any time the set of timers changes
 *   'finished' (timer)      a timer hit zero
 *   'removed'  (timer, why) a timer left the board ('cancelled' | 'expired')
 *
 * State is written to disk on every change so a restart (or a crash) does not
 * lose timers that are mid-countdown.
 */
export class TimerStore extends EventEmitter {
  constructor({ durationMs, finishedDisplayMs, filePath = null, now = Date.now }) {
    super();
    this.durationMs = durationMs;
    this.finishedDisplayMs = finishedDisplayMs;
    this.filePath = filePath;
    this.now = now;
    this.timers = new Map(); // room value -> timer
    this.interval = null;
  }

  // --- public API -------------------------------------------------------

  start(roomValue, startedBy) {
    const room = getRoom(roomValue);
    if (!room) throw new TimerError('UNKNOWN_ROOM', `Unknown room "${roomValue}"`);

    const existing = this.timers.get(room.value);
    if (existing?.status === 'running') {
      throw new TimerError('ROOM_BUSY', `${room.label} already has a timer running`, existing);
    }
    // A finished timer still flashing on screen is replaced straight away.

    // One running timer per person. (Timers started through the HTTP API have
    // no user ID, so this doesn't apply to them.)
    if (startedBy?.id) {
      for (const t of this.timers.values()) {
        if (t.status === 'running' && t.startedBy.id === startedBy.id) {
          throw new TimerError('USER_BUSY', `You already have a ${t.label} timer running`, t);
        }
      }
    }

    const startedAt = this.now();
    const timer = {
      id: randomUUID(),
      room: room.value,
      label: room.label,
      startedBy: { id: startedBy?.id ?? null, name: startedBy?.name ?? 'unknown' },
      startedAt,
      endsAt: startedAt + this.durationMs,
      status: 'running',
    };
    this.timers.set(room.value, timer);
    log.info(`Timer started: ${room.label} by ${timer.startedBy.name}`);
    this.#changed();
    return timer;
  }

  /** Cancel by timer ID. If `userId` is given, only that user's timer may be cancelled. */
  cancel(timerId, { userId = null } = {}) {
    const timer = this.getById(timerId);
    if (!timer) throw new TimerError('NOT_FOUND', 'That timer has already finished or been cancelled');
    if (userId && timer.startedBy.id !== userId) {
      throw new TimerError('NOT_OWNER', 'Only the person who started this timer can cancel it', timer);
    }
    if (timer.status !== 'running') {
      throw new TimerError('ALREADY_FINISHED', 'That timer has already finished', timer);
    }
    this.timers.delete(timer.room);
    log.info(`Timer cancelled: ${timer.label}`);
    this.emit('removed', timer, 'cancelled');
    this.#changed();
    return timer;
  }

  getById(timerId) {
    for (const t of this.timers.values()) if (t.id === timerId) return t;
    return null;
  }

  getByRoom(roomValue) {
    return this.timers.get(roomValue) ?? null;
  }

  snapshot() {
    return {
      serverNow: this.now(),
      finishedDisplayMs: this.finishedDisplayMs,
      timers: [...this.timers.values()]
        .sort((a, b) => a.endsAt - b.endsAt)
        .map((t) => ({ ...t })),
    };
  }

  /** Move timers along their lifecycle. Called on an interval; safe to call any time. */
  tick() {
    const now = this.now();
    let changed = false;
    for (const t of [...this.timers.values()]) {
      if (t.status === 'running' && now >= t.endsAt) {
        t.status = 'finished';
        changed = true;
        log.info(`Timer finished: ${t.label}`);
        this.emit('finished', t);
      }
      if (t.status === 'finished' && now >= t.endsAt + this.finishedDisplayMs) {
        this.timers.delete(t.room);
        changed = true;
        this.emit('removed', t, 'expired');
      }
    }
    if (changed) this.#changed();
  }

  startTicking(everyMs = 250) {
    this.stopTicking();
    this.interval = setInterval(() => this.tick(), everyMs);
    this.interval.unref?.();
  }

  stopTicking() {
    if (this.interval) clearInterval(this.interval);
    this.interval = null;
  }

  // --- persistence ------------------------------------------------------

  load() {
    if (!this.filePath || !fs.existsSync(this.filePath)) return;
    try {
      const saved = JSON.parse(fs.readFileSync(this.filePath, 'utf8'));
      for (const t of saved.timers ?? []) {
        const room = getRoom(t.room);
        if (!room || typeof t.endsAt !== 'number') continue;
        this.timers.set(room.value, { ...t, label: room.label });
      }
      log.info(`Restored ${this.timers.size} timer(s) from ${this.filePath}`);
      this.tick(); // drop anything that ran out while we were down
    } catch (err) {
      log.warn(`Could not read saved timers (${err.message}); starting empty`);
    }
  }

  save() {
    if (!this.filePath) return;
    try {
      fs.mkdirSync(path.dirname(this.filePath), { recursive: true });
      const tmp = `${this.filePath}.tmp`;
      fs.writeFileSync(tmp, JSON.stringify({ timers: [...this.timers.values()] }, null, 2));
      fs.renameSync(tmp, this.filePath); // atomic replace, no half-written files
    } catch (err) {
      log.error(`Could not save timers: ${err.message}`);
    }
  }

  #changed() {
    this.save();
    this.emit('change', this.snapshot());
  }
}
