import 'dotenv/config';
import path from 'node:path';
import { slidesEmbedUrl } from './slides.js';
import { lanAddress } from './network.js';
import os from 'node:os';

const errors = [];

function str(name, { required = false, fallback = '' } = {}) {
  const v = (process.env[name] ?? '').trim();
  if (!v && required) errors.push(`${name} is required`);
  return v || fallback;
}

function int(name, fallback, { min = 0 } = {}) {
  const raw = (process.env[name] ?? '').trim();
  if (!raw) return fallback;
  const n = Number(raw);
  if (!Number.isInteger(n) || n < min) {
    errors.push(`${name} must be a whole number >= ${min} (got "${raw}")`);
    return fallback;
  }
  return n;
}

function snowflake(name, { required = false } = {}) {
  const v = str(name, { required });
  if (v && !/^\d{17,20}$/.test(v)) errors.push(`${name} doesn't look like a Discord ID (got "${v}")`);
  return v;
}

const discordEnabled = str('DISCORD_ENABLED', { fallback: 'true' }).toLowerCase() !== 'false';
const slidesDelay = int('SLIDES_DELAY_MS', 8000, { min: 1000 });
const slidesInput = str('GOOGLE_SLIDES_URL');
const gmSlidesInput = str('GM_GOOGLE_SLIDES_URL');
const reloadTime = str('DISPLAY_RELOAD_TIME', { fallback: '17:00' });

const accentColor = str('DISPLAY_ACCENT_COLOR');
if (accentColor && !/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(accentColor)) {
  errors.push(`DISPLAY_ACCENT_COLOR must be a hex colour like #d8793a (got "${accentColor}")`);
}

if (reloadTime &&!/^([01]\d|2[0-3]):[0-5]\d$/.test(reloadTime)) {
  errors.push(`DISPLAY_RELOAD_TIME must be HH:MM in 24h format (got "${reloadTime}")`);
}
if (Number(process.env.DISCORD_REPLY_DELETE_MS) > 14 * 60 * 1000) {
  errors.push('DISCORD_REPLY_DELETE_MS can be at most 840000 (14 minutes); Discord blocks deletes after 15');
}
if (slidesInput && !slidesEmbedUrl(slidesInput, slidesDelay)) {
  errors.push('GOOGLE_SLIDES_URL is not a Google Slides URL or presentation ID');
}
if (gmSlidesInput && !slidesEmbedUrl(gmSlidesInput, slidesDelay)) {
  errors.push('GM_GOOGLE_SLIDES_URL is not a Google Slides URL or presentation ID');
}

const mdnsName = str('MDNS_NAME', { fallback: 'rpg-timers' }).replace(/\.local\.?$/i, '');
if (mdnsName && mdnsName.toLowerCase() !== 'off' && !/^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$/i.test(mdnsName)) {
  errors.push(`MDNS_NAME must be letters, numbers and hyphens, like rpg-timers (got "${mdnsName}")`);
}
if (mdnsName && mdnsName.toLowerCase() === os.hostname().toLowerCase()) {
  errors.push(
    `MDNS_NAME "${mdnsName}" is the same as this Pi's hostname, which Avahi already uses. ` +
      'Pick a different name (e.g. rpg-timers) so the two don\'t fight over it.',
  );
}

// A second .local name that opens the GM screen directly: http://gm.local:3000
const gmMdnsName = str('GM_MDNS_NAME', { fallback: 'gm' }).replace(/\.local\.?$/i, '');
if (gmMdnsName && gmMdnsName.toLowerCase() !== 'off') {
  if (!/^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?$/i.test(gmMdnsName)) {
    errors.push(`GM_MDNS_NAME must be letters, numbers and hyphens, like gm (got "${gmMdnsName}")`);
  }
  if (gmMdnsName.toLowerCase() === os.hostname().toLowerCase()) {
    errors.push(`GM_MDNS_NAME "${gmMdnsName}" is the same as this Pi's hostname; pick a different name.`);
  }
  if (gmMdnsName.toLowerCase() === mdnsName.toLowerCase()) {
    errors.push('GM_MDNS_NAME and MDNS_NAME must be different names.');
  }
}

const port = int('PORT', 3000, { min: 1 });
const host = str('HOST', { fallback: '0.0.0.0' });

let publicUrl = str('PUBLIC_URL').replace(/\/+$/, '');
if (publicUrl && !/^https?:\/\/[^/\s]+$/i.test(publicUrl)) {
  errors.push(`PUBLIC_URL must look like http://192.168.0.94:3000 (got "${publicUrl}")`);
}
if (!publicUrl) {
  const ip = host !== '0.0.0.0' && host !== '::' ? host : lanAddress();
  if (ip) publicUrl = `http://${ip}:${port}`;
}

export const config = {
  discord: {
    enabled: discordEnabled,
    token: str('DISCORD_TOKEN', { required: discordEnabled }),
    clientId: snowflake('DISCORD_CLIENT_ID', { required: discordEnabled }),
    guildId: snowflake('DISCORD_GUILD_ID'),
    gmRoleId: snowflake('DISCORD_GM_ROLE_ID'),
    timerChannelId: snowflake('DISCORD_TIMER_CHANNEL_ID', { required: discordEnabled }),
    // Discord stops letting a bot touch its private replies 15 minutes after
    // the button press, so anything longer than ~14 minutes can't be honoured.
    replyDeleteMs: int('DISCORD_REPLY_DELETE_MS', 8 * 60 * 1000, { min: 0 }),
  },
  server: {
    port,
    host,
    publicUrl: publicUrl || null, // base address people on the LAN use to reach this server
    apiToken: str('API_TOKEN'),
  },
  display: {
    slidesEmbedUrl: slidesEmbedUrl(slidesInput, slidesDelay),
    // The /gm page uses its own deck; falls back to the bar deck if not set.
    gmSlidesEmbedUrl: slidesEmbedUrl(gmSlidesInput || slidesInput, slidesDelay),
    reloadTime: reloadTime || null,
    accentColor: accentColor || null,
  },
  timers: {
    durationMs: int('TIMER_DURATION_MS', 5 * 60 * 1000, { min: 1000 }),
    finishedDisplayMs: int('TIMER_FINISHED_DISPLAY_MS', 20 * 1000, { min: 0 }),
    extendMs: int('TIMER_EXTEND_MS', 60 * 1000, { min: 1000 }),
  },
  mdns: {
    name: mdnsName.toLowerCase() === 'off' ? null : mdnsName.toLowerCase() || null,
    gmName: gmMdnsName.toLowerCase() === 'off' ? null : gmMdnsName.toLowerCase() || null,
  },
  dataDir: path.resolve(str('DATA_DIR', { fallback: './data' })),
};

if (errors.length) {
  console.error('Configuration problems in .env:\n  - ' + errors.join('\n  - '));
  process.exit(1);
}
