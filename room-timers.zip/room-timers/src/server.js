import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { randomUUID, timingSafeEqual } from 'node:crypto';
import { TimerError } from './timers.js';
import { ROOMS } from './rooms.js';
import { log } from './logger.js';

const publicDir = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'public');

// Changes every time the process starts. Displays compare it on reconnect and
// reload themselves, so a restart (e.g. after changing GOOGLE_SLIDES_URL)
// reaches the screen without anyone touching it.
const bootId = randomUUID();

const LOCALHOST = new Set(['127.0.0.1', '::1', '::ffff:127.0.0.1']);

function tokensMatch(given, expected) {
  const a = Buffer.from(given ?? '');
  const b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}

/** Milliseconds from `now` until the next HH:MM in the server's local time zone. */
export function msUntilNext(hhmm, now = new Date()) {
  const [h, m] = hhmm.split(':').map(Number);
  const next = new Date(now);
  next.setHours(h, m, 0, 0);
  if (next <= now) next.setDate(next.getDate() + 1);
  return next - now;
}

export function createServer({ config, store }) {
  const app = express();
  app.disable('x-powered-by');
  app.use(express.json({ limit: '10kb' }));

  const clients = new Set();

  function send(res, event, data) {
    res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
  }
  function broadcast(event, data) {
    for (const res of clients) send(res, event, data);
  }

  store.on('change', (snapshot) => broadcast('timers', snapshot));

  // --- routes -------------------------------------------------------------

  app.get('/healthz', (_req, res) => res.json({ ok: true, displays: clients.size }));

  // Each screen gets its own slideshow: '/' is the bar, '/gm' is the GM page.
  const SCREENS = {
    bar: () => config.display.slidesEmbedUrl,
    gm: () => config.display.gmSlidesEmbedUrl,
  };

  app.get('/api/config', (req, res) => {
    const screen = SCREENS[req.query.screen] ? req.query.screen : 'bar';
    res.json({
      bootId,
      screen,
      slidesEmbedUrl: SCREENS[screen](),
      accentColor: config.display.accentColor,
      rooms: ROOMS,
    });
  });

  app.get('/api/timers', (_req, res) => res.json(store.snapshot()));

  // Server-Sent Events: pushes the full timer list on every change.
  app.get('/api/events', (req, res) => {
    res.set({
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no', // in case it ever sits behind nginx
    });
    res.flushHeaders();
    res.write('retry: 3000\n\n');
    send(res, 'hello', { bootId });
    send(res, 'timers', store.snapshot());
    clients.add(res);
    log.info(`Display connected (${req.ip}); ${clients.size} connected`);
    req.on('close', () => {
      clients.delete(res);
      log.info(`Display disconnected (${req.ip}); ${clients.size} connected`);
    });
  });

  // Optional external control: { "action": "start", "room": "GUILDHALL" }
  //                         or { "action": "cancel", "timerId": "..." }
  // With API_TOKEN set it needs "Authorization: Bearer <token>".
  // With API_TOKEN blank it only accepts calls from this machine.
  app.post('/api/timer-events', (req, res) => {
    const { apiToken } = config.server;
    if (apiToken) {
      const given = (req.get('authorization') || '').replace(/^Bearer\s+/i, '');
      if (!tokensMatch(given, apiToken)) return res.status(401).json({ error: 'Unauthorized' });
    } else if (!LOCALHOST.has(req.socket.remoteAddress)) {
      return res.status(403).json({ error: 'Set API_TOKEN to allow calls from other machines' });
    }

    const { action, room, timerId, startedBy } = req.body ?? {};
    try {
      if (action === 'start') {
        const timer = store.start(room, { id: null, name: String(startedBy || 'API').slice(0, 64) });
        return res.status(201).json(timer);
      }
      if (action === 'cancel') {
        const id = timerId ?? store.getByRoom(room)?.id;
        return res.json(store.cancel(id));
      }
      return res.status(400).json({ error: 'action must be "start" or "cancel"' });
    } catch (err) {
      if (err instanceof TimerError) {
        const status = { UNKNOWN_ROOM: 400, ROOM_BUSY: 409, NOT_FOUND: 404 }[err.code] ?? 409;
        return res.status(status).json({ error: err.message, code: err.code });
      }
      throw err;
    }
  });

  // Anyone opening gm.local (GM_MDNS_NAME) goes straight to the GM screen.
  const gmHost = config.mdns?.gmName ? `${config.mdns.gmName}.local` : null;
  app.get('/', (req, res, next) => {
    if (gmHost && req.hostname?.toLowerCase() === gmHost) return res.redirect(302, '/gm');
    next();
  });

  // The old bot served the screen at /display.html; keep screens set up for it working.
  app.get('/display.html', (_req, res) => res.redirect(301, '/'));

  // Same page as the bar screen; display.js picks the GM deck from the path.
  app.get(['/gm', '/gm/'], (_req, res) => res.sendFile(path.join(publicDir, 'index.html')));

  app.use(express.static(publicDir, { index: 'index.html', maxAge: 0 }));

  app.use((err, _req, res, _next) => {
    log.error('HTTP error:', err);
    res.status(500).json({ error: 'Internal error' });
  });

  // --- SSE keep-alive and daily display reload ----------------------------

  const heartbeat = setInterval(() => {
    for (const res of clients) res.write(': ping\n\n');
  }, 25_000);

  let reloadTimer = null;
  function scheduleReload() {
    if (!config.display.reloadTime) return;
    const wait = msUntilNext(config.display.reloadTime);
    reloadTimer = setTimeout(() => {
      log.info(`Daily reload: telling ${clients.size} display(s) to refresh`);
      broadcast('reload', { reason: 'daily' });
      scheduleReload();
    }, wait);
    log.info(`Next display reload at ${new Date(Date.now() + wait).toString()}`);
  }
  scheduleReload();

  // --- lifecycle ----------------------------------------------------------

  let httpServer;
  return {
    listen() {
      return new Promise((resolve, reject) => {
        httpServer = app.listen(config.server.port, config.server.host, () => {
          log.info(`Display server on http://${config.server.host}:${config.server.port}`);
          resolve(httpServer);
        });
        httpServer.once('error', reject);
      });
    },
    async close() {
      clearInterval(heartbeat);
      clearTimeout(reloadTimer);
      for (const res of clients) res.end();
      clients.clear();
      if (httpServer) await new Promise((r) => httpServer.close(r));
    },
  };
}
