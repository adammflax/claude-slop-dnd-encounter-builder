import os from 'node:os';

// The server's address on the local network (e.g. 192.168.0.94), used for the
// GM page link posted in Discord. Prefers private LAN ranges.
export function lanAddress(interfaces = os.networkInterfaces()) {
  const v4 = Object.values(interfaces)
    .flat()
    .filter((i) => i && (i.family === 'IPv4' || i.family === 4) && !i.internal)
    .map((i) => i.address);
  const isPrivate = (a) => /^(192\.168\.|10\.|172\.(1[6-9]|2\d|3[01])\.)/.test(a);
  return v4.find(isPrivate) ?? v4[0] ?? null;
}
