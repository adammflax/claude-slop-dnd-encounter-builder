// Accepts the normal share URL (.../presentation/d/<ID>/edit), a
// "Publish to the web" URL (.../presentation/d/e/<PUB_ID>/pub), or a bare ID,
// and turns it into an autoplaying, looping embed URL. Returns null if it
// can't make sense of the input.
export function slidesEmbedUrl(input, delayMs) {
  if (!input) return null;
  const params = `start=true&loop=true&delayms=${delayMs}&rm=minimal`;
  const published = input.match(/\/presentation\/d\/e\/([\w-]+)/);
  if (published) return `https://docs.google.com/presentation/d/e/${published[1]}/embed?${params}`;
  const shared = input.match(/\/presentation\/d\/([\w-]+)/);
  const id = shared ? shared[1] : /^[\w-]{20,}$/.test(input) ? input : null;
  if (!id) return null;
  return `https://docs.google.com/presentation/d/${id}/embed?${params}`;
}
